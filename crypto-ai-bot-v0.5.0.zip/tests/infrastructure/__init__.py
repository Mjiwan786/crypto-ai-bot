"""Tests for infrastructure components."""

