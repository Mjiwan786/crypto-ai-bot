#!/usr/bin/env python3
"""
Crypto AI Bot - Main Entry Point

A production-ready crypto trading system with multi-agent architecture,
Redis streams, and comprehensive monitoring.

Usage:
    python -m main run --mode paper --strategy momentum
    python -m main health
    python -m main slo --duration 60
"""

import argparse
import asyncio
import json
import logging
import os
import signal
import sys
import time
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Configure structured logging
def setup_logging(level: str = "INFO") -> logging.Logger:
    """Setup structured logging with JSON format"""
    log_level = getattr(logging, level.upper(), logging.INFO)
    
    # Create logs directory
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)
    
    # Configure logging
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(logs_dir / "crypto_ai_bot.log")
        ]
    )
    
    return logging.getLogger(__name__)

# Global state for graceful shutdown
_shutdown_requested = False
_logger = None

def signal_handler(signum, frame):
    """Handle graceful shutdown signals"""
    global _shutdown_requested
    _logger.info(f"Received signal {signum}, initiating graceful shutdown...")
    _shutdown_requested = True

async def run_command(args) -> None:
    """Run the trading bot with specified parameters"""
    _logger.info("Starting crypto AI bot in run mode")
    _logger.info(f"Mode: {args.mode}")
    _logger.info(f"Strategy: {args.strategy}")
    _logger.info(f"Config: {args.config}")
    _logger.info(f"Dry run: {args.dry_run}")
    
    # Validate mode
    if args.mode == "live":
        confirmation = os.getenv("LIVE_TRADING_CONFIRMATION")
        if confirmation != "I-accept-the-risk":
            _logger.error("Live trading requires LIVE_TRADING_CONFIRMATION=I-accept-the-risk")
            sys.exit(1)
        _logger.warning("LIVE TRADING ENABLED - Real money at risk!")
    
    # Load configuration
    try:
        from config.unified_config_loader import load_system_config
        config = load_system_config(environment=args.mode)
        _logger.info("Configuration loaded successfully")
    except Exception as e:
        _logger.error(f"Failed to load configuration: {e}")
        sys.exit(1)
    
    # Initialize trading system
    try:
        from orchestration.master_orchestrator import MasterOrchestrator
        orchestrator = MasterOrchestrator(config_path=args.config)
        
        if not await orchestrator.initialize():
            _logger.error("Failed to initialize orchestrator")
            sys.exit(1)
        
        _logger.info("Trading system initialized successfully")
        
        # Start the system
        await orchestrator.start()
        _logger.info("Trading system started")
        
        # Main trading loop
        while not _shutdown_requested:
            try:
                # Simulate trading cycle
                _logger.info("Executing trading cycle...")
                await asyncio.sleep(1)  # Placeholder for actual trading logic
                
            except Exception as e:
                _logger.error(f"Trading cycle error: {e}")
                await asyncio.sleep(5)  # Wait before retry
        
        # Graceful shutdown
        await orchestrator.stop()
        _logger.info("Trading system stopped gracefully")
        
    except Exception as e:
        _logger.error(f"Failed to run trading system: {e}")
        sys.exit(1)

async def health_command(args) -> None:
    """Check system health and Redis connectivity"""
    _logger.info("Running health check")
    
    health_status = {
        "timestamp": datetime.utcnow().isoformat(),
        "status": "unknown",
        "redis": {"connected": False, "error": None},
        "system": {"python_version": sys.version, "environment": os.getenv("ENVIRONMENT", "unknown")}
    }
    
    # Check Redis connectivity
    try:
        import redis
        from urllib.parse import urlparse
        
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        _logger.info(f"Connecting to Redis: {redis_url}")
        
        # Parse URL to determine if TLS is needed
        parsed = urlparse(redis_url)
        use_ssl = parsed.scheme == "rediss"
        
        if use_ssl:
            # TLS connection
            import ssl
            ssl_context = ssl.create_default_context()
            ca_cert_path = os.getenv("REDIS_TLS_CERT_PATH", "/etc/ssl/certs/ca-certificates.crt")
            
            if os.path.exists(ca_cert_path):
                ssl_context.load_verify_locations(ca_cert_path)
            
            client = redis.from_url(
                redis_url,
                ssl_cert_reqs=ssl.CERT_REQUIRED,
                ssl_ca_certs=ca_cert_path,
                decode_responses=True
            )
        else:
            # Non-TLS connection
            client = redis.from_url(redis_url, decode_responses=True)
        
        # Test connection
        start_time = time.time()
        pong = client.ping()
        latency = (time.time() - start_time) * 1000
        
        if pong:
            health_status["redis"]["connected"] = True
            health_status["redis"]["latency_ms"] = round(latency, 2)
            health_status["redis"]["url"] = redis_url
            health_status["status"] = "healthy"
            _logger.info(f"Redis health check passed (latency: {latency:.2f}ms)")
        else:
            health_status["redis"]["error"] = "PING failed"
            health_status["status"] = "unhealthy"
            _logger.error("Redis PING failed")
            
    except Exception as e:
        health_status["redis"]["error"] = str(e)
        health_status["status"] = "unhealthy"
        _logger.error(f"Redis health check failed: {e}")
    
    # Output JSON result
    print(json.dumps(health_status, indent=2))
    
    # Exit with appropriate code
    if health_status["status"] == "healthy":
        sys.exit(0)
    else:
        sys.exit(1)

async def slo_command(args) -> None:
    """Simulate decision→publish timings and report SLO metrics"""
    _logger.info(f"Running SLO simulation for {args.duration} seconds")
    
    timings = []
    start_time = time.time()
    
    try:
        # Simulate decision→publish cycles
        while time.time() - start_time < args.duration and not _shutdown_requested:
            cycle_start = time.time()
            
            # Simulate decision making
            await asyncio.sleep(0.01)  # 10ms decision time
            
            # Simulate publish operation
            await asyncio.sleep(0.005)  # 5ms publish time
            
            cycle_end = time.time()
            total_latency = (cycle_end - cycle_start) * 1000  # Convert to ms
            timings.append(total_latency)
            
            _logger.debug(f"Cycle latency: {total_latency:.2f}ms")
            
            # Small delay between cycles
            await asyncio.sleep(0.1)
    
    except KeyboardInterrupt:
        _logger.info("SLO simulation interrupted by user")
    
    # Calculate statistics
    if timings:
        timings.sort()
        p50 = timings[len(timings) // 2]
        p95 = timings[int(len(timings) * 0.95)]
        p99 = timings[int(len(timings) * 0.99)]
        
        slo_report = {
            "timestamp": datetime.utcnow().isoformat(),
            "duration_seconds": args.duration,
            "total_cycles": len(timings),
            "latency_stats": {
                "min_ms": round(min(timings), 2),
                "max_ms": round(max(timings), 2),
                "avg_ms": round(sum(timings) / len(timings), 2),
                "p50_ms": round(p50, 2),
                "p95_ms": round(p95, 2),
                "p99_ms": round(p99, 2)
            },
            "slo_compliance": {
                "p95_under_500ms": p95 < 500,
                "p50_under_100ms": p50 < 100
            }
        }
        
        print(json.dumps(slo_report, indent=2))
        
        # Check SLO compliance
        if slo_report["slo_compliance"]["p95_under_500ms"]:
            _logger.info("✅ SLO compliance: P95 latency under 500ms")
            sys.exit(0)
        else:
            _logger.warning("❌ SLO violation: P95 latency exceeds 500ms")
            sys.exit(1)
    else:
        _logger.error("No timing data collected")
        sys.exit(1)

def validate_mode(mode: str) -> bool:
    """Validate trading mode"""
    valid_modes = ["paper", "live"]
    if mode not in valid_modes:
        print(f"Error: Invalid mode '{mode}'. Must be one of: {', '.join(valid_modes)}")
        return False
    return True

def cli() -> None:
    """Main CLI entry point"""
    global _logger
    
    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create argument parser
    parser = argparse.ArgumentParser(
        description="Crypto AI Bot - Production Trading System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m main run --mode paper --strategy momentum
  python -m main health
  python -m main slo --duration 60
        """
    )
    
    # Add subcommands
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Run subcommand
    run_parser = subparsers.add_parser("run", help="Run the trading bot")
    run_parser.add_argument(
        "--mode", 
        choices=["paper", "live"], 
        default="paper",
        help="Trading mode (default: paper)"
    )
    run_parser.add_argument(
        "--config",
        default="config/settings.yaml",
        help="Configuration file path (default: config/settings.yaml)"
    )
    run_parser.add_argument(
        "--strategy",
        default="momentum",
        help="Trading strategy to use (default: momentum)"
    )
    run_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate trading without executing orders"
    )
    
    # Health subcommand
    health_parser = subparsers.add_parser("health", help="Check system health")
    
    # SLO subcommand
    slo_parser = subparsers.add_parser("slo", help="Run SLO simulation")
    slo_parser.add_argument(
        "--duration",
        type=int,
        default=60,
        help="Simulation duration in seconds (default: 60)"
    )
    
    # Parse arguments
    args = parser.parse_args()
    
    # Setup logging
    log_level = os.getenv("LOG_LEVEL", "INFO")
    _logger = setup_logging(log_level)
    
    # Validate mode if provided
    if hasattr(args, 'mode') and not validate_mode(args.mode):
        sys.exit(1)
    
    # Run appropriate command
    try:
        if args.command == "run":
            asyncio.run(run_command(args))
        elif args.command == "health":
            asyncio.run(health_command(args))
        elif args.command == "slo":
            asyncio.run(slo_command(args))
        else:
            parser.print_help()
            sys.exit(1)
    except KeyboardInterrupt:
        _logger.info("Received keyboard interrupt, shutting down...")
        sys.exit(0)
    except Exception as e:
        _logger.error(f"Command failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    cli()