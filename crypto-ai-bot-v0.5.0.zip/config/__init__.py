# This package contains YAML configuration and a loader to merge them.
