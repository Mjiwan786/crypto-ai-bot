# Exchange‑agnostic utility functions.
