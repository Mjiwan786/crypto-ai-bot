"""
Redis Cloud TLS connection utility for crypto-ai-bot.

Features:
- Redis Cloud TLS connection with SSL context building
- Exponential backoff with jitter for resilient operations
- Health check integration with existing redis_health module
- Context manager support for proper resource cleanup
- Integration points for data_pipeline and kraken_ingestor
- Settings-driven SSL configuration

Usage:
    from agents.infrastructure.redis_client import RedisCloudClient
    
    async with RedisCloudClient() as client:
        await client.ping()
        await client.set("key", "value")
"""

from __future__ import annotations

import asyncio
import logging
import os
import random
import ssl
from contextlib import asynccontextmanager
from typing import Any, Dict, Optional

import redis.asyncio as redis
from pydantic import BaseModel, Field, field_validator

from agents.infrastructure.redis_health import RedisHealthChecker, RedisHealthConfig, RedisHealthResult

logger = logging.getLogger(__name__)


class RedisCloudConfig(BaseModel):
    """Configuration for Redis Cloud TLS connection."""
    
    # Connection settings
    url: str = Field(default_factory=lambda: os.getenv("REDIS_URL", "rediss://localhost:6380"))
    ca_cert_path: Optional[str] = Field(default_factory=lambda: os.getenv("REDIS_CA_CERT"))
    client_cert_path: Optional[str] = Field(default_factory=lambda: os.getenv("REDIS_CLIENT_CERT"))
    client_key_path: Optional[str] = Field(default_factory=lambda: os.getenv("REDIS_CLIENT_KEY"))
    
    # Timeout settings
    connect_timeout: float = Field(default=10.0, ge=1.0, le=60.0)
    socket_timeout: float = Field(default=10.0, ge=1.0, le=60.0)
    
    # Retry settings
    max_retries: int = Field(default=5, ge=1, le=20)
    base_delay: float = Field(default=0.5, ge=0.1, le=5.0)
    max_delay: float = Field(default=30.0, ge=5.0, le=300.0)
    
    # Connection pool settings
    max_connections: int = Field(default=20, ge=1, le=100)
    retry_on_timeout: bool = Field(default=True)
    health_check_interval: int = Field(default=15, ge=5, le=300)
    
    # Client identification
    client_name: str = Field(default="crypto-ai-bot-cloud")
    decode_responses: bool = Field(default=True)
    
    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Ensure URL is TLS-enabled for Redis Cloud."""
        if not v.startswith("rediss://"):
            raise ValueError("Redis Cloud requires TLS connection (rediss://)")
        return v
    
    @field_validator("ca_cert_path")
    @classmethod
    def validate_ca_cert(cls, v: Optional[str]) -> Optional[str]:
        """Validate CA certificate path if provided."""
        if v and not os.path.exists(v):
            raise FileNotFoundError(f"CA certificate not found: {v}")
        return v
    
    @field_validator("client_cert_path")
    @classmethod
    def validate_client_cert(cls, v: Optional[str]) -> Optional[str]:
        """Validate client certificate path if provided."""
        if v and not os.path.exists(v):
            raise FileNotFoundError(f"Client certificate not found: {v}")
        return v
    
    @field_validator("client_key_path")
    @classmethod
    def validate_client_key(cls, v: Optional[str]) -> Optional[str]:
        """Validate client key path if provided."""
        if v and not os.path.exists(v):
            raise FileNotFoundError(f"Client key not found: {v}")
        return v


class RedisCloudClient:
    """
    Redis Cloud TLS client with exponential backoff, health checks, and context manager support.
    
    Designed for production use with Redis Cloud, providing:
    - Automatic TLS/SSL context building
    - Exponential backoff with jitter for resilience
    - Health check integration
    - Proper resource cleanup via context manager
    - Connection pooling and timeout management
    """
    
    def __init__(self, config: Optional[RedisCloudConfig] = None):
        """Initialize Redis Cloud client with configuration."""
        self.config = config or RedisCloudConfig()
        self._client: Optional[redis.Redis] = None
        self._connection_pool: Optional[redis.ConnectionPool] = None
        self._health_checker: Optional[RedisHealthChecker] = None
        self._is_connected = False
        
        # Setup health checker
        health_config = RedisHealthConfig(
            url=self.config.url,
            ca_cert_path=self.config.ca_cert_path,
            client_cert_path=self.config.client_cert_path,
            client_key_path=self.config.client_key_path,
            connect_timeout=self.config.connect_timeout,
            socket_timeout=self.config.socket_timeout,
            max_retries=self.config.max_retries,
            base_delay=self.config.base_delay,
            max_delay=self.config.max_delay,
        )
        self._health_checker = RedisHealthChecker(health_config)
    
    def _build_ssl_context(self) -> ssl.SSLContext:
        """Build SSL context for Redis Cloud TLS connection."""
        if not self.config.ca_cert_path:
            # Use default SSL context if no CA cert provided
            context = ssl.create_default_context()
            context.check_hostname = True
            context.verify_mode = ssl.CERT_REQUIRED
            logger.warning("No CA certificate provided, using default SSL context")
            return context
        
        # Create context with custom CA
        context = ssl.create_default_context(cafile=self.config.ca_cert_path)
        context.check_hostname = True
        context.verify_mode = ssl.CERT_REQUIRED
        
        # Add mTLS support if client cert/key provided
        if self.config.client_cert_path and self.config.client_key_path:
            context.load_cert_chain(
                self.config.client_cert_path,
                self.config.client_key_path
            )
            logger.debug("mTLS client certificates loaded")
        elif self.config.client_cert_path or self.config.client_key_path:
            logger.warning("Both client cert and key must be provided for mTLS")
        
        return context
    
    def _get_connection_params(self) -> Dict[str, Any]:
        """Get connection parameters for Redis client."""
        params = {
            "socket_timeout": self.config.socket_timeout,
            "socket_connect_timeout": self.config.connect_timeout,
            "retry_on_timeout": self.config.retry_on_timeout,
            "health_check_interval": self.config.health_check_interval,
            "decode_responses": self.config.decode_responses,
            "client_name": self.config.client_name,
            "max_connections": self.config.max_connections,
        }
        
        # For redis-py 6.x, use ssl_context instead of ssl parameter
        params["ssl_context"] = self._build_ssl_context()
        
        return params
    
    async def _exponential_backoff_delay(self, attempt: int) -> float:
        """Calculate exponential backoff delay with jitter."""
        raw_delay = self.config.base_delay * (2 ** attempt)
        jitter = random.uniform(0, raw_delay * 0.1)  # 10% jitter
        return min(raw_delay + jitter, self.config.max_delay)
    
    async def _create_client(self) -> redis.Redis:
        """Create Redis client with retry logic."""
        # For redis-py 6.x, use the simplified approach like the working TLS check
        for attempt in range(self.config.max_retries):
            try:
                # Use the same approach as the working check_redis_tls.py script
                client = redis.from_url(
                    self.config.url,
                    socket_timeout=self.config.socket_timeout,
                    socket_connect_timeout=self.config.connect_timeout,
                    retry_on_timeout=self.config.retry_on_timeout,
                    health_check_interval=self.config.health_check_interval,
                    decode_responses=self.config.decode_responses,
                    client_name=self.config.client_name,
                    max_connections=self.config.max_connections,
                )
                
                # Test connection
                await client.ping()
                logger.info("Redis Cloud connection established successfully")
                return client
            except Exception as e:
                if attempt == self.config.max_retries - 1:
                    logger.error(f"Failed to connect to Redis Cloud after {self.config.max_retries} attempts: {e}")
                    raise
                
                delay = await self._exponential_backoff_delay(attempt)
                logger.warning(f"Connection attempt {attempt + 1} failed: {e}. Retrying in {delay:.2f}s")
                await asyncio.sleep(delay)
        
        raise RuntimeError("Unexpected error in connection retry logic")
    
    async def connect(self) -> None:
        """Establish connection to Redis Cloud."""
        if self._is_connected:
            return
        
        try:
            self._client = await self._create_client()
            self._is_connected = True
            logger.info("Connected to Redis Cloud")
        except Exception as e:
            logger.error(f"Failed to connect to Redis Cloud: {e}")
            raise
    
    async def disconnect(self) -> None:
        """Disconnect from Redis Cloud."""
        if self._client:
            try:
                await self._client.aclose()
                logger.info("Disconnected from Redis Cloud")
            except Exception as e:
                logger.warning(f"Error during disconnect: {e}")
            finally:
                self._client = None
                self._is_connected = False
    
    async def health_check(self) -> RedisHealthResult:
        """Perform health check using integrated health checker."""
        if not self._health_checker:
            return RedisHealthResult(connected=False, error_message="Health checker not initialized")
        
        return await self._health_checker.check_health()
    
    async def ping(self) -> bool:
        """Ping Redis server with retry logic."""
        if not self._client:
            raise RuntimeError("Client not connected")
        
        for attempt in range(self.config.max_retries):
            try:
                result = await self._client.ping()
                return bool(result)
            except Exception as e:
                if attempt == self.config.max_retries - 1:
                    logger.error(f"Ping failed after {self.config.max_retries} attempts: {e}")
                    return False
                
                delay = await self._exponential_backoff_delay(attempt)
                logger.warning(f"Ping attempt {attempt + 1} failed: {e}. Retrying in {delay:.2f}s")
                await asyncio.sleep(delay)
        
        return False
    
    # Context manager support
    async def __aenter__(self) -> "RedisCloudClient":
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.disconnect()
    
    # Delegate Redis operations to underlying client
    def __getattr__(self, name: str) -> Any:
        """Delegate attribute access to underlying Redis client."""
        if not self._client:
            raise RuntimeError("Client not connected")
        return getattr(self._client, name)


# Convenience functions for integration points
async def get_redis_cloud_client(config: Optional[RedisCloudConfig] = None) -> RedisCloudClient:
    """Get a Redis Cloud client instance."""
    client = RedisCloudClient(config)
    await client.connect()
    return client


@asynccontextmanager
async def redis_cloud_connection(config: Optional[RedisCloudConfig] = None):
    """Context manager for Redis Cloud connection."""
    client = RedisCloudClient(config)
    try:
        await client.connect()
        yield client
    finally:
        await client.disconnect()


# Integration helper for data_pipeline
async def create_data_pipeline_redis_client() -> redis.Redis:
    """
    Create Redis client for data_pipeline integration.
    
    Returns the underlying redis.Redis client for compatibility with existing data_pipeline code.
    """
    config = RedisCloudConfig()
    client = RedisCloudClient(config)
    await client.connect()
    return client._client


# Integration helper for kraken_ingestor
async def create_kraken_ingestor_redis_client() -> redis.Redis:
    """
    Create Redis client for kraken_ingestor integration.
    
    Returns the underlying redis.Redis client for compatibility with existing kraken_ingestor code.
    """
    config = RedisCloudConfig()
    client = RedisCloudClient(config)
    await client.connect()
    return client._client


# Health check utility
async def check_redis_cloud_health(config: Optional[RedisCloudConfig] = None) -> RedisHealthResult:
    """Check Redis Cloud health without establishing persistent connection."""
    if config is None:
        config = RedisCloudConfig()
    
    health_config = RedisHealthConfig(
        url=config.url,
        ca_cert_path=config.ca_cert_path,
        client_cert_path=config.client_cert_path,
        client_key_path=config.client_key_path,
        connect_timeout=config.connect_timeout,
        socket_timeout=config.socket_timeout,
        max_retries=config.max_retries,
        base_delay=config.base_delay,
        max_delay=config.max_delay,
    )
    
    checker = RedisHealthChecker(health_config)
    return await checker.check_health()

