"""
AutoGen wrappers for crypto trading agents.

Provides AutoGen agent wrappers that bind to existing project tools and functions.
Replaces LangChain tool calling with explicit function calls via AutoGen tools.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, timezone

try:
    from autogen_agentchat import AssistantAgent, Tool
    from autogen_core import Agent
except ImportError:
    # Fallback for when AutoGen is not installed
    AssistantAgent = None
    Tool = None
    Agent = Any

logger = logging.getLogger(__name__)


def _place_order_kraken(intent: Dict[str, Any]) -> Dict[str, Any]:
    """Place order on Kraken with validated OrderIntent."""
    try:
        # Import here to avoid circular imports
        from agents.core.execution_agent import EnhancedExecutionAgent
        
        # Create execution agent and execute signal
        execution_agent = EnhancedExecutionAgent()
        
        # Convert order intent to signal format if needed
        signal_data = {
            "symbol": intent.get("symbol", "BTC/USDT"),
            "side": intent.get("side", "buy"),
            "amount": intent.get("amount", 0.001),
            "strategy": intent.get("strategy", "momentum"),
            "timestamp": datetime.now(timezone.utc).timestamp(),
        }
        
        # Execute the order (this would be async in real usage)
        import asyncio
        result = asyncio.run(execution_agent.execute_signal(signal_data))
        
        if result:
            return {
                "status": "success",
                "order_id": getattr(result, "order_id", "unknown"),
                "fill_price": getattr(result, "fill_price", 0.0),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        else:
            return {
                "status": "failed",
                "error": "No result from execution agent",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            
    except Exception as e:
        logger.error(f"Failed to place order: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


def _publish_signal(signal: Dict[str, Any]) -> bool:
    """Publish a trading signal to Redis/MCP bus."""
    try:
        # Import here to avoid circular imports
        from agents.core.signal_processor import SignalProcessor
        from mcp.redis_manager import RedisManager
        
        # Create signal processor and publish signal
        # In a real implementation, this would use the actual Redis bus
        symbol = signal.get('symbol', 'N/A')
        side = signal.get('side', 'N/A')
        size = signal.get('size', 'N/A')
        logger.info(f"Signal published: {symbol} {side} size={size} stream=autogen redis_id=simulated")
        
        # Simulate successful publication
        return True
        
    except Exception as e:
        logger.error(f"Failed to publish signal: {e}")
        return False


def _check_risk_limits(signal: Dict[str, Any]) -> Dict[str, Any]:
    """Check risk limits for a trading signal."""
    try:
        # Import here to avoid circular imports
        from agents.risk.risk_router import route_signal
        
        # Route signal through risk checks
        risk_ok, order_intent = route_signal(signal)
        
        return {
            "risk_ok": risk_ok,
            "order_intent": order_intent,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
    except Exception as e:
        logger.error(f"Failed to check risk limits: {e}")
        return {
            "risk_ok": False,
            "order_intent": None,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


def _analyze_market_data(symbol: str, features: Dict[str, Any]) -> Dict[str, Any]:
    """Analyze market data and generate trading signal."""
    try:
        # Import here to avoid circular imports
        from agents.core.signal_analyst import generate_signal
        
        # Generate signal using existing signal analyst
        signal = generate_signal(symbol, features)
        
        return {
            "signal": signal,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        
    except Exception as e:
        logger.error(f"Failed to analyze market data: {e}")
        return {
            "signal": None,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


# Create AutoGen tools
if Tool is not None:
    place_order_tool = Tool(
        func=_place_order_kraken,
        name="place_order_kraken",
        description="Place order on Kraken with validated OrderIntent."
    )
    
    publish_signal_tool = Tool(
        func=_publish_signal,
        name="publish_signal",
        description="Publish a trading signal to Redis/MCP bus."
    )
    
    check_risk_tool = Tool(
        func=_check_risk_limits,
        name="check_risk_limits",
        description="Check risk limits for a trading signal."
    )
    
    analyze_market_tool = Tool(
        func=_analyze_market_data,
        name="analyze_market_data",
        description="Analyze market data and generate trading signal."
    )
else:
    # Fallback when AutoGen is not available
    place_order_tool = None
    publish_signal_tool = None
    check_risk_tool = None
    analyze_market_tool = None


# Create AutoGen agents
if AssistantAgent is not None:
    execution_agent = AssistantAgent(
        name="ExecutionAgent",
        tools=[place_order_tool] if place_order_tool else [],
        description="Executes trading orders on Kraken exchange."
    )
    
    signal_agent = AssistantAgent(
        name="SignalAgent",
        tools=[publish_signal_tool, analyze_market_tool] if publish_signal_tool else [],
        description="Generates and publishes trading signals."
    )
    
    risk_agent = AssistantAgent(
        name="RiskAgent",
        tools=[check_risk_tool] if check_risk_tool else [],
        description="Performs risk checks on trading signals."
    )
else:
    # Fallback when AutoGen is not available
    execution_agent = None
    signal_agent = None
    risk_agent = None


def run_execution(order_intent: Dict[str, Any]) -> Dict[str, Any]:
    """Execute order using AutoGen execution agent."""
    if execution_agent is None:
        logger.warning("AutoGen not available, falling back to direct execution")
        return _place_order_kraken(order_intent)
    
    try:
        # Run the execution agent
        response = execution_agent.run(
            input=f"Execute order intent: {order_intent}"
        )
        
        # Extract result from AutoGen response
        if hasattr(response, 'content'):
            return response.content
        else:
            return response
            
    except Exception as e:
        logger.error(f"AutoGen execution failed: {e}")
        return _place_order_kraken(order_intent)


def emit_signal(signal: Dict[str, Any]) -> bool:
    """Emit signal using AutoGen signal agent."""
    if signal_agent is None:
        logger.warning("AutoGen not available, falling back to direct signal emission")
        return _publish_signal(signal)
    
    try:
        # Run the signal agent
        response = signal_agent.run(
            input=f"Publish signal: {signal}"
        )
        
        # Extract result from AutoGen response
        if hasattr(response, 'content'):
            return bool(response.content)
        else:
            return bool(response)
            
    except Exception as e:
        logger.error(f"AutoGen signal emission failed: {e}")
        return _publish_signal(signal)


def check_risk(signal: Dict[str, Any]) -> Dict[str, Any]:
    """Check risk using AutoGen risk agent."""
    if risk_agent is None:
        logger.warning("AutoGen not available, falling back to direct risk check")
        return _check_risk_limits(signal)
    
    try:
        # Run the risk agent
        response = risk_agent.run(
            input=f"Check risk for signal: {signal}"
        )
        
        # Extract result from AutoGen response
        if hasattr(response, 'content'):
            return response.content
        else:
            return response
            
    except Exception as e:
        logger.error(f"AutoGen risk check failed: {e}")
        return _check_risk_limits(signal)


def analyze_market(symbol: str, features: Dict[str, Any]) -> Dict[str, Any]:
    """Analyze market using AutoGen signal agent."""
    if signal_agent is None:
        logger.warning("AutoGen not available, falling back to direct market analysis")
        return _analyze_market_data(symbol, features)
    
    try:
        # Run the signal agent
        response = signal_agent.run(
            input=f"Analyze market for {symbol} with features: {features}"
        )
        
        # Extract result from AutoGen response
        if hasattr(response, 'content'):
            return response.content
        else:
            return response
            
    except Exception as e:
        logger.error(f"AutoGen market analysis failed: {e}")
        return _analyze_market_data(symbol, features)


# Example usage
if __name__ == "__main__":
    # Test the wrappers
    test_signal = {
        "symbol": "BTC/USDT",
        "side": "buy",
        "amount": 0.001,
        "strategy": "momentum",
        "timestamp": datetime.now(timezone.utc).timestamp(),
    }
    
    print("Testing AutoGen wrappers...")
    
    # Test market analysis
    result = analyze_market("BTC/USDT", {"price": 50000, "volume": 1000})
    print(f"Market analysis result: {result}")
    
    # Test risk check
    risk_result = check_risk(test_signal)
    print(f"Risk check result: {risk_result}")
    
    # Test signal emission
    signal_emitted = emit_signal(test_signal)
    print(f"Signal emitted: {signal_emitted}")
    
    # Test execution (dry run)
    if risk_result.get("risk_ok"):
        exec_result = run_execution(risk_result.get("order_intent", {}))
        print(f"Execution result: {exec_result}")
