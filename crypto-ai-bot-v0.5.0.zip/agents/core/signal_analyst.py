"""
agents/core/signal_analyst.py - Production Signal Analyst

Analyzes market data, computes features, applies strategy logic and policy constraints,
and emits validated Signal events to Redis streams. Core component of crypto-ai-bot.

Integrates with:
- Redis Cloud via mcp.redis_manager.RedisManager
- Configuration from settings.yaml/scalping_settings.yaml
- MCP schemas for Signal validation
- Policy updates and risk controls
"""
from __future__ import annotations

import asyncio
import logging
import signal
import time
import traceback
import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime
import statistics
import math

# Third-party imports
import yaml
from pydantic import ValidationError

# Project imports (assuming these exist in your project)
try:
    from mcp.schemas import Signal, RiskParameters
    from mcp.redis_manager import RedisManager
    # from mcp import keys  # (unused) remove or use for namespacing
except ImportError:
    # Fallback implementations for standalone operation
    from pydantic import BaseModel, ConfigDict

    class RiskParameters(BaseModel):
        sl_bps: int
        tp_bps: Optional[List[int]] = None
        ttl_s: Optional[int] = None

    class Signal(BaseModel):
        type: str = "signal"
        timestamp: float
        symbol: str
        strategy: str
        side: str  # "buy" or "sell"
        confidence: float
        price: float
        features: Dict[str, Union[float, int]]
        risk: RiskParameters
        notes: Optional[str] = None

        # Allow extra fields for prod-only fields (timeframe/exchange/source)
        model_config = ConfigDict(extra="allow")  # Pydantic v2

        def to_json(self) -> str:
            return self.model_dump_json()


# Configuration and Policy Management
@dataclass
class PolicySnapshot:
    """Minimal cached view of policy constraints"""
    allocations: Optional[Dict[str, float]] = None
    max_spread_bps: Optional[float] = None
    daily_stop: Optional[float] = None
    cooldown_between_signals_s: Optional[int] = None
    version: Optional[str] = None


class Config:
    """Configuration loader for strategy and global settings"""

    def __init__(self, config_path: str = "config/settings.yaml", scalping_path: str = "config/scalping_settings.yaml"):
        self.config_path = config_path
        self.scalping_path = scalping_path
        self._load_config()

    def _load_config(self):
        """Load configuration from YAML files with environment variable substitution

        Precedence: ENV > scalping_settings.yaml > settings.yaml > defaults
        """
        # Default values from environment or hardcoded
        self.min_confidence = float(os.getenv("MIN_CONFIDENCE", "0.72"))
        self.prefer_post_only = os.getenv("PREFER_POST_ONLY", "true").lower() == "true"
        self.account_equity_usd = float(os.getenv("ACCOUNT_EQUITY_USD", "10000"))
        self.feature_window = int(os.getenv("FEATURE_WINDOW", "20"))
        self.log_level = os.getenv("LOG_LEVEL", "INFO")
        self.dry_run = os.getenv("DRY_RUN", "false").lower() == "true"

        # Risk parameters from environment
        self.risk = {
            "sl_bps": int(os.getenv("SCALP_STOP_LOSS_BPS", "6")),
            "tp_bps": [int(x) for x in os.getenv("SCALP_TARGET_BPS", "12,20").split(",")],
            "ttl_s": int(os.getenv("SCALP_MAX_HOLD_SECONDS", "300")),
        }

        # Stream configuration - align with your env
        self.streams = {
            "out_signals": os.getenv("PAPER_REDIS_STREAM", "signals:paper")
        }

        # Scalping strategy tunable thresholds - externalized
        self.scalping_thresholds = {
            "tight_spread_bps": float(os.getenv("SCALP_TIGHT_SPREAD_BPS", "2.0")),
            "max_spread_bps": float(os.getenv("SCALP_MAX_SPREAD_BPS", "10.0")),
            "min_volume_ratio": float(os.getenv("SCALP_MIN_VOLUME_RATIO", "1.0")),
            "high_volume_ratio": float(os.getenv("SCALP_HIGH_VOLUME_RATIO", "1.5")),
            "min_momentum_bps": float(os.getenv("SCALP_MIN_MOMENTUM_BPS", "2.0")),
            "max_momentum_bps": float(os.getenv("SCALP_MAX_MOMENTUM_BPS", "8.0")),
            "high_volatility_bps": float(os.getenv("SCALP_HIGH_VOLATILITY_BPS", "50.0")),
            "price_vs_mid_threshold_bps": float(os.getenv("SCALP_PRICE_VS_MID_THRESHOLD_BPS", "1.0")),
        }

        # Load from YAML if files exist
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    config_data = yaml.safe_load(f)
                    self._merge_yaml_config(config_data)

            if os.path.exists(self.scalping_path):
                with open(self.scalping_path, 'r') as f:
                    scalp_data = yaml.safe_load(f)
                    self._merge_scalp_config(scalp_data)

        except Exception as e:
            logging.warning(f"Could not load YAML config: {e}, using environment defaults")

    def _merge_yaml_config(self, config_data: dict):
        """Merge YAML configuration with defaults"""
        if "trading" in config_data:
            trading = config_data["trading"]
            if "entries" in trading:
                entries = trading["entries"]
                self.min_confidence = entries.get("min_confidence", self.min_confidence)

        if "strategies" in config_data and "scalp" in config_data["strategies"]:
            scalp = config_data["strategies"]["scalp"] or {}
            self.risk["sl_bps"] = scalp.get("stop_loss_bps", self.risk["sl_bps"])
            tgt = scalp.get("target_bps", self.risk["tp_bps"])
            self.risk["tp_bps"] = tgt if isinstance(tgt, list) else [int(tgt)]
            self.risk["ttl_s"] = scalp.get("max_hold_seconds", self.risk["ttl_s"])

    def _merge_scalp_config(self, scalp_data: dict):
        """Merge scalping-specific configuration"""
        if "min_confidence" in scalp_data:
            self.min_confidence = scalp_data["min_confidence"]
        if "risk" in scalp_data:
            risk_config = scalp_data["risk"]
            self.risk.update(risk_config)


def load_policy_snapshot(redis_manager: Optional[RedisManager] = None) -> PolicySnapshot:
    """Load current policy snapshot with safe defaults"""
    try:
        # Try to load from Redis policy stream if available
        if redis_manager:
            # TODO: Implement real policy fetch from Redis
            pass
    except Exception:
        pass

    # Return safe defaults
    return PolicySnapshot(
        allocations=None,
        max_spread_bps=float(os.getenv("SPREAD_BPS_MAX", "12.0")),
        daily_stop=float(os.getenv("DAILY_STOP_LOSS", "-0.03")),
        cooldown_between_signals_s=int(os.getenv("SCALP_COOLDOWN_SECONDS", "90")),
        version="static_defaults_v1",
    )


class MarketFeatures:
    """Market feature computation and management"""

    def __init__(self, window_size: int = 20):
        self.window_size = window_size
        self.price_history: List[float] = []
        self.volume_history: List[float] = []
        self.timestamp_history: List[float] = []
        self.last_bid = None
        self.last_ask = None
        self.last_spread_bps = None

    def update_tick(self, price: float, volume: float, timestamp: float):
        """Update with new tick data"""
        self.price_history.append(price)
        self.volume_history.append(volume)
        self.timestamp_history.append(timestamp)

        # Maintain rolling window
        if len(self.price_history) > self.window_size:
            self.price_history.pop(0)
            self.volume_history.pop(0)
            self.timestamp_history.pop(0)

    def update_quote(self, bid: float, ask: float):
        """Update with new quote data"""
        self.last_bid = bid
        self.last_ask = ask
        if bid > 0 and ask > bid:
            self.last_spread_bps = ((ask - bid) / bid) * 10000

    def compute_features(self) -> Dict[str, float]:
        """Compute numerical features from market data"""
        features = {}

        if not self.price_history:
            return features

        try:
            # Basic price features
            current_price = self.price_history[-1]
            features["price"] = current_price

            if len(self.price_history) >= 2:
                # Price change features
                prev_price = self.price_history[-2]
                features["price_change_bps"] = ((current_price - prev_price) / prev_price) * 10000

                # Volatility - use consistent window from feature_window
                window_size = min(len(self.price_history), self.window_size) - 1
                if window_size >= 4:
                    returns = []
                    for i in range(window_size):
                        ret = (self.price_history[-(i + 1)] - self.price_history[-(i + 2)]) / self.price_history[-(i + 2)]
                        returns.append(ret)
                    if returns:
                        features["volatility"] = statistics.stdev(returns) * 10000  # in bps

            # Volume features
            if self.volume_history:
                features["volume"] = self.volume_history[-1]
                if len(self.volume_history) >= 5:
                    recent_avg_vol = statistics.mean(self.volume_history[-5:])
                    features["volume_ratio"] = self.volume_history[-1] / recent_avg_vol if recent_avg_vol > 0 else 1.0

            # Quote features
            if self.last_bid is not None and self.last_ask is not None:
                features["bid"] = self.last_bid
                features["ask"] = self.last_ask
                features["spread_bps"] = self.last_spread_bps or 0.0
                features["mid_price"] = (self.last_bid + self.last_ask) / 2.0

                # Price vs mid deviation
                mid_price = features["mid_price"]
                features["price_vs_mid_bps"] = ((current_price - mid_price) / mid_price) * 10000.0

            # Technical indicators
            if len(self.price_history) >= 10:
                sma_5 = statistics.mean(self.price_history[-5:])
                sma_10 = statistics.mean(self.price_history[-10:])
                features["sma_5"] = sma_5
                features["sma_10"] = sma_10
                features["price_vs_sma5_bps"] = ((current_price - sma_5) / sma_5) * 10000
                features["price_vs_sma10_bps"] = ((current_price - sma_10) / sma_10) * 10000

                if len(self.price_history) >= 14:
                    roc = ((current_price - self.price_history[-14]) / self.price_history[-14]) * 100
                    features["roc_14"] = roc

            # Time-based features
            if self.timestamp_history and len(self.timestamp_history) >= 2:
                time_since_last = self.timestamp_history[-1] - self.timestamp_history[-2]
                features["time_delta"] = time_since_last

        except Exception as e:
            logging.warning(f"Error computing features: {e}")

        return features


class SignalAnalyst:
    """Main Signal Analyst class - orchestrates market analysis and signal generation"""

    def __init__(
        self,
        redis: Optional[RedisManager],
        symbol: str,
        strategy: str,
        config: Config,
        stream_out: str = "signals:paper",
    ):
        self.redis = redis
        self.symbol = symbol
        self.strategy = strategy
        self.config = config
        self.stream_out = stream_out or config.streams["out_signals"]

        # Setup logging
        self.logger = logging.getLogger(f"SignalAnalyst.{strategy}.{symbol}")
        self.logger.setLevel(getattr(logging, config.log_level.upper()))

        # Market data management
        self.features_engine = MarketFeatures(window_size=config.feature_window)
        self.last_signal_time = 0
        self.signal_count = 0
        self.rejection_counts = {}

        # Policy and state
        self.current_policy = load_policy_snapshot(redis)
        self.last_policy_update = time.time()
        self.policy_refresh_interval = 300  # 5 minutes

        # Daily P&L tracking for policy enforcement (basic placeholder)
        self._daily_pnl = 0.0
        self._last_reset_date = datetime.now().date()

        # Performance tracking
        self.metrics = {
            "signals_emitted": 0,
            "signals_rejected": 0,
            "analyzer_latency_samples": [],
            "features_latency_samples": [],
        }

        # Operational state
        self.running = False
        self.backoff_delay = 0.1  # Start at 100ms
        self.max_backoff = 2.0    # Max 2 seconds

        self.logger.info(f"SignalAnalyst initialized: {strategy} on {symbol}")
        if self.current_policy.version == "static_defaults_v1":
            self.logger.info("Using static policy defaults until policy service ships")

    def now(self) -> float:
        """Get current timestamp - helper for testing"""
        return time.time()

    def _install_signals(self):
        """Install signal handlers for graceful shutdown - safe for async/threading"""
        import threading

        if threading.current_thread() is threading.main_thread():
            def signal_handler(signum, frame):
                self.logger.info(f"Received signal {signum}, shutting down gracefully...")
                self.running = False

            for sig in (getattr(signal, "SIGINT", None), getattr(signal, "SIGTERM", None)):
                if sig:
                    signal.signal(sig, signal_handler)

    async def run_forever(self) -> None:
        """Main loop with graceful shutdown and reconnect/backoff"""
        self.running = True
        self.logger.info(f"Starting SignalAnalyst main loop for {self.symbol}")

        self._install_signals()
        consecutive_errors = 0

        while self.running:
            try:
                if time.time() - self.last_policy_update > self.policy_refresh_interval:
                    self.current_policy = load_policy_snapshot(self.redis)
                    self.last_policy_update = time.time()

                await asyncio.sleep(max(0.01, self.backoff_delay))

                # Reset backoff on success
                self.backoff_delay = 0.1
                consecutive_errors = 0

                if self.signal_count % 100 == 0 and self.signal_count > 0:
                    self._log_metrics()

            except Exception as e:
                consecutive_errors += 1
                self.logger.error(f"Error in main loop (attempt {consecutive_errors}): {e}")
                self.logger.debug(f"Traceback: {traceback.format_exc()}")

                self.backoff_delay = min(self.backoff_delay * 1.5, self.max_backoff)
                jitter = self.backoff_delay * 0.1
                await asyncio.sleep(self.backoff_delay + jitter)

                if consecutive_errors >= 10:
                    self.logger.warning("Too many consecutive errors, resetting state")
                    consecutive_errors = 0
                    self.backoff_delay = 0.1

        self.logger.info("SignalAnalyst main loop stopped")

    async def process_market_event(self, event: dict) -> None:
        """Process incoming market event and potentially generate signals"""
        start_time = time.time()

        try:
            if not self._validate_event(event):
                return

            event_type = event.get("type", "")

            if event_type == "trade":
                price = float(event["price"])
                volume = float(event["volume"])
                timestamp = float(event.get("timestamp", self.now()))
                self.features_engine.update_tick(price, volume, timestamp)

            elif event_type == "quote":
                bid = float(event["bid"])
                ask = float(event["ask"])
                self.features_engine.update_quote(bid, ask)

            else:
                self.logger.debug(f"Ignoring event type: {event_type}")
                return

            # Build features
            features_start = time.time()
            features = self.build_features(event)
            features_latency = (time.time() - features_start) * 1000
            self.metrics["features_latency_samples"].append(features_latency)

            if not features:
                return

            # Score
            score = self.score(features)

            # Emit decision
            should_emit, reason = self.should_emit(score, features, self.current_policy)

            if should_emit:
                signal_obj = self.make_signal(score, features, self.current_policy)
                await self.publish_signal(signal_obj)
                self.metrics["signals_emitted"] += 1
                self.signal_count += 1
                self.last_signal_time = self.now()

                self.logger.info(
                    f"Signal emitted: {self.strategy} {signal_obj.side} {self.symbol} "
                    f"confidence={score:.3f} price={signal_obj.price:.2f}"
                )
            else:
                self.metrics["signals_rejected"] += 1
                self.rejection_counts[reason] = self.rejection_counts.get(reason, 0) + 1
                self.logger.debug(f"Signal rejected: {reason}")

        except Exception as e:
            self.logger.error(f"Error processing market event: {e}")
            self.logger.debug(f"Event: {event}")
        finally:
            total_latency = (time.time() - start_time) * 1000
            self.metrics["analyzer_latency_samples"].append(total_latency)
            for key in ["analyzer_latency_samples", "features_latency_samples"]:
                if len(self.metrics[key]) > 1000:
                    self.metrics[key] = self.metrics[key][-500:]

    def build_features(self, event: dict) -> Dict[str, float]:
        """Build numerical features from market event"""
        features = self.features_engine.compute_features()

        # Add event-specific features
        if event.get("type") == "trade":
            features["last_trade_price"] = float(event["price"])
            features["last_trade_volume"] = float(event["volume"])
            features["trade_side"] = 1.0 if event.get("side", "").lower() == "buy" else -1.0

        # Filter to only numeric features and clean data
        clean_features = {}
        for key, value in features.items():
            try:
                if isinstance(value, (int, float)) and not (math.isnan(value) or math.isinf(value)):
                    clean_features[key] = float(value)
            except (TypeError, ValueError):
                continue

        return clean_features

    def score(self, features: Dict[str, float]) -> float:
        """Score the trading opportunity based on features"""
        if not features:
            return 0.0

        try:
            if self.strategy == "scalp":
                return self._score_scalping(features)
            else:
                return self._score_default(features)
        except Exception as e:
            self.logger.warning(f"Error in scoring: {e}")
            return 0.0

    def _score_scalping(self, features: Dict[str, float]) -> float:
        """Scalping strategy scoring logic with externalized thresholds"""
        score = 0.0

        # Required features
        for feature in ["spread_bps", "volume_ratio"]:
            if feature not in features:
                return 0.0

        spread_bps = features["spread_bps"]
        volume_ratio = features.get("volume_ratio", 1.0)
        th = self.config.scalping_thresholds

        # Tight spread
        if spread_bps <= th["tight_spread_bps"]:
            score += 0.4
        elif spread_bps <= 4.0:
            score += 0.2
        elif spread_bps > th["max_spread_bps"]:
            return 0.0

        # Volume
        if volume_ratio >= th["high_volume_ratio"]:
            score += 0.2
        elif volume_ratio >= th["min_volume_ratio"]:
            score += 0.1

        # Momentum
        if "price_change_bps" in features:
            price_change = abs(features["price_change_bps"])
            if th["min_momentum_bps"] <= price_change <= th["max_momentum_bps"]:
                score += 0.2
            elif price_change > 15.0:
                score -= 0.2

        # Volatility
        if "volatility" in features:
            vol = features["volatility"]
            if vol > th["high_volatility_bps"]:
                score -= 0.3

        # Price vs mid near zero
        if "price_vs_mid_bps" in features:
            deviation = abs(features["price_vs_mid_bps"])
            if deviation <= th["price_vs_mid_threshold_bps"]:
                score += 0.1

        return max(0.0, min(1.0, score))

    def _score_default(self, features: Dict[str, float]) -> float:
        """Default scoring for non-scalping strategies"""
        score = 0.5
        if "roc_14" in features:
            momentum = features["roc_14"]
            if abs(momentum) > 2.0:
                score += 0.2
        if features.get("volume_ratio", 1.0) > 1.2:
            score += 0.1
        return max(0.0, min(1.0, score))

    def should_emit(self, score: float, features: Dict[str, float], policy: PolicySnapshot) -> Tuple[bool, Optional[str]]:
        """Determine if signal should be emitted based on score, features, and policy"""

        # Daily P&L reset logic
        today = datetime.now().date()
        if getattr(self, "_last_reset_date", today) != today:
            self._daily_pnl = 0.0
            self._last_reset_date = today
            self.logger.info(f"Daily P&L reset for {today}")

        if score < self.config.min_confidence:
            return False, f"LOW_CONFIDENCE_{score:.3f}"

        if math.isnan(score) or math.isinf(score) or score < 0 or score > 1:
            return False, "BAD_SCORE"

        # Price validation
        price = features.get("price") or features.get("mid_price") or features.get("ask")
        if not isinstance(price, (int, float)) or not math.isfinite(price) or price <= 0:
            return False, "BAD_PRICE"

        # Quote availability
        if "bid" not in features or "ask" not in features:
            return False, "NO_QUOTE"

        # Spread sanity
        spread_bps = features.get("spread_bps", 999)
        if spread_bps <= 0 or spread_bps > 500:
            if spread_bps > 500:
                self.logger.warning(f"Absurd spread detected: {self.symbol} spread={spread_bps:.1f}bps")
            return False, "BAD_SPREAD"

        # Policy spread cap
        max_spread = policy.max_spread_bps if policy.max_spread_bps else 15.0
        if spread_bps > max_spread:
            return False, f"SPREAD_TOO_WIDE_{spread_bps:.1f}"

        # Daily stop (placeholder - only if PnL tracking active)
        if policy.daily_stop and hasattr(self, "_daily_pnl") and self._daily_pnl != 0:
            if self._daily_pnl <= policy.daily_stop:
                return False, f"DAILY_STOP_HIT_{policy.daily_stop}"

        # Allocation
        if policy.allocations and self.strategy in policy.allocations:
            strategy_alloc = policy.allocations[self.strategy]
            if strategy_alloc <= 0:
                return False, f"STRATEGY_DISABLED_ALLOC_{strategy_alloc}"

        # Cooldown
        if self.last_signal_time > 0:
            cooldown = policy.cooldown_between_signals_s if policy.cooldown_between_signals_s else 30
            time_since_last = self.now() - self.last_signal_time
            if time_since_last < cooldown:
                return False, f"COOLDOWN_{int(cooldown - time_since_last)}s"

        # Volume check
        if "volume" in features and features["volume"] <= 0:
            return False, "NO_VOLUME"

        return True, None

    def make_signal(self, score: float, features: Dict[str, float], policy: PolicySnapshot) -> Signal:
        """Create Signal object from score and features"""
        side = self._determine_side(features)
        price = features.get("price", features.get("mid_price", features.get("ask", 0)))

        risk = {
            "sl_bps": self.config.risk["sl_bps"],
            "tp_bps": self.config.risk.get("tp_bps"),
            "ttl_s": self.config.risk.get("ttl_s"),
        }

        notes = self._generate_notes(score, features)

        signal_obj = Signal(
            type="signal",
            timestamp=self.now(),
            symbol=self.symbol,
            strategy=self.strategy,
            side=side,
            confidence=score,
            price=price,
            features=features,
            risk=risk,
            notes=notes,
            timeframe=os.getenv("SCALP_TIMEFRAME", "15s"),
            exchange=os.getenv("EXCHANGE", "kraken"),
            source="signal_analyst",
        )

        return signal_obj

    def _determine_side(self, features: Dict[str, float]) -> str:
        """Determine signal side (buy/sell) using microstructure + hysteresis.

        Rules:
        - Mean-reversion vs. mid with momentum/volume confirmation.
        - Sticky memory: require a small extra bias (hysteresis) to flip from last side.
        - Deterministic default if no prior decision.
        """
        now_ts = self.now()
        last = getattr(self, "_last_side", None)

        # Safely pull & clamp inputs
        th = self.config.scalping_thresholds
        price_vs_mid = float(features.get("price_vs_mid_bps", 0.0))
        momentum = float(features.get("price_change_bps", 0.0))
        volume_ratio = float(features.get("volume_ratio", 1.0))

        if not math.isfinite(price_vs_mid):
            price_vs_mid = 0.0
        if not math.isfinite(momentum):
            momentum = 0.0
        if not math.isfinite(volume_ratio) or volume_ratio <= 0:
            volume_ratio = 1.0

        # Guard against absurd spreads - aligned with should_emit
        spread_bps = float(features.get("spread_bps", 999.0))
        if spread_bps <= 0 or spread_bps >= 500:
            if last:
                return last
            return "buy"

        # Use config thresholds for consistency with scoring
        price_bias = float(th.get("price_vs_mid_threshold_bps", 2.0))
        vol_high = float(th.get("high_volume_ratio", 1.5))
        vol_min = float(th.get("min_volume_ratio", 1.0))
        # Extra bias required to FLIP away from the last side (hysteresis)
        flip_bias = price_bias + getattr(self, "_side_hysteresis_bps", 0.4)

        # Helper: can we flip yet (time guard)?
        can_flip = (now_ts - getattr(self, "_last_side_ts", 0.0)) >= getattr(self, "_side_flip_guard_s", 3.0)

        decided: Optional[str] = None

        if self.strategy == "scalp":
            # Mean reversion core + confirmation
            if price_vs_mid > price_bias:
                if (momentum < 0) or (volume_ratio >= vol_high):
                    decided = "sell"
            elif price_vs_mid < -price_bias:
                if (momentum > 0) or (volume_ratio >= vol_high):
                    decided = "buy"

            # Tight zone near mid: momentum micro-push
            if decided is None and abs(price_vs_mid) <= price_bias:
                if momentum >= 1.0 and volume_ratio >= vol_min:
                    decided = "buy"
                elif momentum <= -1.0 and volume_ratio >= vol_min:
                    decided = "sell"

            # Hysteresis (resist flapping)
            if decided and last and decided != last and not can_flip:
                decided = last
            elif decided and last and decided != last and can_flip:
                if decided == "buy" and price_vs_mid > -flip_bias:
                    decided = last
                elif decided == "sell" and price_vs_mid < flip_bias:
                    decided = last

            # If still undecided, stick with last side if possible
            if decided is None and last is not None:
                decided = last

        # Default for other strategies or if still None
        if decided is None:
            decided = "buy" if momentum >= 0 else "sell"

        # Optional logging: trace flips for production debugging
        try:
            if self.logger.isEnabledFor(logging.DEBUG) and last != decided:
                self.logger.debug(
                    f"Side flip {last}->{decided} | p_mid={price_vs_mid:.2f}bps mom={momentum:.2f}bps v={volume_ratio:.2f}x"
                )
        except Exception:
            pass

        # Persist decision + timestamp for hysteresis
        self._last_side = decided
        self._last_side_ts = now_ts
        return decided

    def _generate_notes(self, score: float, features: Dict[str, float]) -> str:
        """Generate concise signal notes"""
        spread = features.get("spread_bps", 0.0)
        volume_ratio = features.get("volume_ratio", 1.0)
        notes = f"{self.strategy} s={spread:.1f}bps v={volume_ratio:.1f}x"
        if len(notes) > 140:
            notes = notes[:137] + "..."
        return notes

    async def publish_signal(self, sig: Signal) -> None:
        """Publish validated signal to Redis stream"""
        start_time = time.time()
        try:
            signal_json = sig.to_json()

            if self.redis and not self.config.dry_run:
                stream_data = {
                    "signal": signal_json,
                    "timestamp": str(sig.timestamp),
                    "symbol": sig.symbol,
                    "strategy": sig.strategy,
                    "side": sig.side,
                    "confidence": f"{sig.confidence:.3f}",
                }

                if hasattr(self.redis, 'xadd'):
                    redis_id = await self.redis.xadd(self.stream_out, stream_data)
                elif hasattr(self.redis, 'client') and hasattr(self.redis.client, 'xadd'):
                    redis_id = await self.redis.client.xadd(self.stream_out, stream_data)
                else:
                    self.logger.error("Redis manager does not support xadd interface")
                    self.metrics["signals_rejected"] += 1
                    return

                # Metrics instrumentation
                try:
                    from monitoring.metrics_exporter import inc_signals_published, observe_publish_latency_ms
                    from monitoring.slo_metrics import record_signal_latency
                    latency_ms = (time.time() - start_time) * 1000
                    inc_signals_published(agent=self.strategy, stream=self.stream_out, symbol=sig.symbol)
                    observe_publish_latency_ms(agent=self.strategy, stream=self.stream_out, latency_ms)
                    
                    # Record e2e latency to Redis for SLO monitoring
                    signal_payload = {
                        "signal_id": getattr(sig, 'signal_id', str(sig.timestamp)),
                        "symbol": sig.symbol,
                        "strategy": sig.strategy,
                        "side": sig.side,
                        "confidence": sig.confidence
                    }
                    redis_client = self.redis if hasattr(self.redis, 'xadd') else (self.redis.client if hasattr(self.redis, 'client') else None)
                    if redis_client:
                        await record_signal_latency(
                            agent=self.strategy, 
                            stream=self.stream_out, 
                            latency_ms=latency_ms,
                            signal_payload=signal_payload,
                            redis_client=redis_client
                        )
                except ImportError:
                    pass  # Metrics not available
                except Exception as e:
                    self.logger.warning(f"Failed to record SLO metrics: {e}")
                
                # Discord alert for signal published
                try:
                    from monitoring.discord_alerts import send_trading_alert
                    send_trading_alert(
                        sig.symbol, 
                        f"Signal published: {sig.side} (confidence: {sig.confidence:.2f})", 
                        "INFO",
                        strategy=self.strategy,
                        confidence=f"{sig.confidence:.2f}",
                        latency_ms=f"{latency_ms:.1f}"
                    )
                except ImportError:
                    pass  # Discord alerts not available
                except Exception:
                    pass  # Don't fail signal publishing on Discord errors

                # Log signal emission with required fields
                self.logger.info(f"Signal published: {sig.symbol} {sig.side} size={sig.features.get('size', 'N/A')} stream={self.stream_out} redis_id={redis_id}")

            elif self.config.dry_run:
                self.logger.info(f"[DRY RUN] Would publish signal: {signal_json}")
            else:
                self.logger.warning("No Redis connection available, signal not published")

        except ValidationError as e:
            self.logger.error(f"Signal validation failed: {e}")
            self.metrics["signals_rejected"] += 1
            self.rejection_counts["VALIDATION_ERROR"] = self.rejection_counts.get("VALIDATION_ERROR", 0) + 1

        except Exception as e:
            self.logger.error(f"Failed to publish signal: {e}")
            self.metrics["signals_rejected"] += 1
            # Metrics instrumentation for Redis errors
            try:
                from monitoring.metrics_exporter import inc_redis_publish_error
                inc_redis_publish_error(stream=self.stream_out)
            except ImportError:
                pass  # Metrics not available
            self.rejection_counts["PUBLISH_ERROR"] = self.rejection_counts.get("PUBLISH_ERROR", 0) + 1

    def _validate_event(self, event: dict) -> bool:
        """Validate incoming market event structure"""
        if not isinstance(event, dict):
            return False

        event_type = event.get("type", "")

        if event_type == "trade":
            required_fields = ["price", "volume"]
            return all(field in event for field in required_fields)

        elif event_type == "quote":
            required_fields = ["bid", "ask"]
            return all(field in event for field in required_fields)

        return False

    def _log_metrics(self) -> None:
        """Log performance and operational metrics"""
        analyzer_latencies = self.metrics["analyzer_latency_samples"]
        features_latencies = self.metrics["features_latency_samples"]

        analyzer_p95 = 0.0
        features_p95 = 0.0

        if analyzer_latencies:
            analyzer_latencies.sort()
            analyzer_p95 = analyzer_latencies[int(len(analyzer_latencies) * 0.95)]

        if features_latencies:
            features_latencies.sort()
            features_p95 = features_latencies[int(len(features_latencies) * 0.95)]

        self.logger.info(
            f"Metrics: emitted={self.metrics['signals_emitted']} "
            f"rejected={self.metrics['signals_rejected']} "
            f"analyzer_p95={analyzer_p95:.2f}ms "
            f"features_p95={features_p95:.2f}ms"
        )

        if self.rejection_counts:
            rejection_summary = ", ".join([f"{k}={v}" for k, v in self.rejection_counts.items()])
            self.logger.info(f"Rejection reasons: {rejection_summary}")


# CLI Implementation
def create_cli():
    """Create CLI interface for standalone operation"""
    import argparse

    parser = argparse.ArgumentParser(description="Signal Analyst - Market Analysis and Signal Generation")
    parser.add_argument("--symbol", required=True, help="Trading symbol (e.g., BTC/USD)")
    parser.add_argument("--strategy", default="scalp", help="Strategy name (default: scalp)")
    parser.add_argument("--config", default="config/settings.yaml", help="Config file path")
    parser.add_argument("--stream-out", default="signals:paper", help="Output Redis stream")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument("--dry-run", action="store_true", help="Dry run mode (don't publish signals)")
    parser.add_argument("--test-mode", action="store_true", help="Run in test mode with simulated data")
    parser.add_argument("--redis-url", help="Redis URL (overrides config)")

    return parser


async def simulate_market_data(analyst: SignalAnalyst, duration_seconds: int = 60):
    """Simulate market data for testing with improved realism"""
    import random

    analyst.logger.info(f"Starting market data simulation for {duration_seconds} seconds")

    base_price = 50000.0
    current_price = base_price

    start_time = time.time()

    while time.time() - start_time < duration_seconds and analyst.running:
        # Generate realistic price movement
        price_change = random.gauss(0, 0.001) * current_price  # 0.1% volatility
        current_price = max(current_price + price_change, base_price * 0.95)  # floor 5%
        current_price = min(current_price, base_price * 1.05)  # cap 5%

        # Generate bid/ask spread (2-10 bps) - correlated with volume
        spread_bps = random.uniform(2.0, 10.0)

        # Volume correlated with spread tightness
        if spread_bps <= 3.0:
            volume = random.uniform(0.8, 3.0)
        else:
            volume = random.uniform(0.1, 1.5)

        spread = current_price * (spread_bps / 10000)
        bid = current_price - spread / 2
        ask = current_price + spread / 2

        trade_event = {
            "type": "trade",
            "price": current_price,
            "volume": volume,
            "side": random.choice(["buy", "sell"]),
            "timestamp": time.time(),
        }

        quote_event = {
            "type": "quote",
            "bid": bid,
            "ask": ask,
            "timestamp": time.time(),
        }

        await analyst.process_market_event(trade_event)
        await analyst.process_market_event(quote_event)

        await asyncio.sleep(random.uniform(0.05, 0.2))

    analyst.logger.info("Market data simulation completed")


class MockRedisManager:
    """Mock Redis manager for testing without Redis"""

    def __init__(self):
        self.published_signals = []
        self.logger = logging.getLogger("MockRedisManager")

    async def xadd(self, stream_name: str, data: dict):
        """Mock Redis stream add"""
        self.published_signals.append({
            "stream": stream_name,
            "data": data,
            "timestamp": time.time(),
        })
        self.logger.info(f"Mock published to {stream_name}: {data.get('signal', 'N/A')[:100]}")


async def run_standalone_test():
    """Run standalone test with simulated data"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    logger = logging.getLogger("standalone_test")
    logger.info("Starting SignalAnalyst standalone test")

    mock_redis = MockRedisManager()

    config = Config()
    config.dry_run = False
    config.log_level = "INFO"

    analyst = SignalAnalyst(
        redis=mock_redis,
        symbol="BTC/USD",
        strategy="scalp",
        config=config,
        stream_out="test:signals",
    )

    analyst_task = asyncio.create_task(analyst.run_forever())
    simulation_task = asyncio.create_task(simulate_market_data(analyst, duration_seconds=30))

    try:
        await simulation_task
        analyst.running = False
        await asyncio.sleep(1)
        analyst_task.cancel()
        try:
            await analyst_task
        except asyncio.CancelledError:
            pass

        logger.info(f"Test completed. Signals published: {len(mock_redis.published_signals)}")
        logger.info(f"Final metrics: {analyst.metrics}")

        for i, signal_data in enumerate(mock_redis.published_signals[:3]):
            logger.info(
                f"Sample signal {i+1}: {signal_data['data']['symbol']} "
                f"{signal_data['data']['side']} confidence={signal_data['data']['confidence']}"
            )

    except KeyboardInterrupt:
        logger.info("Test interrupted by user")
        analyst.running = False
        analyst_task.cancel()

    except Exception as e:
        logger.error(f"Test error: {e}")
        analyst.running = False
        analyst_task.cancel()


async def run_production():
    """Run in production mode with real Redis"""
    parser = create_cli()
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    logger = logging.getLogger("signal_analyst_prod")
    logger.info(f"Starting SignalAnalyst: {args.strategy} on {args.symbol}")

    # Load configuration
    try:
        config = Config(config_path=args.config)
        if args.dry_run:
            config.dry_run = True
        logger.info(f"Configuration loaded: min_confidence={config.min_confidence}")
    except Exception as e:
        logger.error(f"Configuration error: {e}")
        return

    # Initialize Redis manager (replace mock with real in prod)
    redis_manager = None
    if not config.dry_run:
        try:
            # from mcp.redis_manager import RedisManager
            # redis_manager = RedisManager(redis_url=args.redis_url or os.getenv("REDIS_URL"))
            # await redis_manager.initialize()
            redis_manager = MockRedisManager()
            logger.info("✅ Redis manager initialized (mock for demo)")
        except Exception as e:
            logger.error(f"Redis initialization failed: {e}")
            logger.info("Continuing in dry-run mode")
            config.dry_run = True

    analyst = SignalAnalyst(
        redis=redis_manager,
        symbol=args.symbol,
        strategy=args.strategy,
        config=config,
        stream_out=args.stream_out,
    )

    try:
        if args.test_mode:
            simulation_task = asyncio.create_task(simulate_market_data(analyst, duration_seconds=60))
            analyst_task = asyncio.create_task(analyst.run_forever())

            await simulation_task
            analyst.running = False
            await asyncio.sleep(1)
            analyst_task.cancel()
            try:
                await analyst_task
            except asyncio.CancelledError:
                pass
        else:
            logger.info("Running in production mode - connect real market data feeds here")
            await analyst.run_forever()

    except KeyboardInterrupt:
        logger.info("Graceful shutdown initiated")
        analyst.running = False
    except Exception as e:
        logger.error(f"Production error: {e}")
        logger.debug(f"Traceback: {traceback.format_exc()}")
    finally:
        logger.info("SignalAnalyst stopped")


# Integration helpers for the broader crypto-ai-bot system
class SignalAnalystManager:
    """Manager class for running multiple signal analysts"""

    def __init__(self, redis_manager):
        self.redis_manager = redis_manager
        self.analysts = {}
        self.logger = logging.getLogger("SignalAnalystManager")

    async def start_analyst(self, symbol: str, strategy: str, config: Config) -> SignalAnalyst:
        """Start a new signal analyst instance"""
        key = f"{strategy}_{symbol}"

        if key in self.analysts:
            self.logger.warning(f"Analyst {key} already exists")
            return self.analysts[key]

        analyst = SignalAnalyst(
            redis=self.redis_manager,
            symbol=symbol,
            strategy=strategy,
            config=config,
            stream_out=config.streams["out_signals"],
        )

        self.analysts[key] = analyst

        task = asyncio.create_task(analyst.run_forever())
        analyst._task = task  # Store reference to task

        self.logger.info(f"Started analyst: {key}")
        return analyst

    async def stop_analyst(self, symbol: str, strategy: str):
        """Stop a signal analyst instance"""
        key = f"{strategy}_{symbol}"

        if key not in self.analysts:
            self.logger.warning(f"Analyst {key} not found")
            return

        analyst = self.analysts[key]
        analyst.running = False

        if hasattr(analyst, "_task"):
            analyst._task.cancel()
            try:
                await analyst._task
            except asyncio.CancelledError:
                pass

        del self.analysts[key]
        self.logger.info(f"Stopped analyst: {key}")

    async def stop_all(self):
        """Stop all signal analysts"""
        keys = list(self.analysts.keys())
        for key in keys:
            strategy, symbol = key.rsplit('_', 1)
            await self.stop_analyst(symbol, strategy)

    def get_analyst_stats(self) -> Dict[str, Dict]:
        """Get statistics for all analysts"""
        stats = {}
        for key, analyst in self.analysts.items():
            stats[key] = {
                "running": analyst.running,
                "signal_count": analyst.signal_count,
                "metrics": analyst.metrics.copy(),
                "rejection_counts": analyst.rejection_counts.copy(),
            }
        return stats


# Market event adapter for integration with existing data feeds
class MarketEventAdapter:
    """Adapter to convert various market data formats to SignalAnalyst events"""

    @staticmethod
    def from_kraken_trade(kraken_data: dict) -> dict:
        """Convert Kraken WebSocket trade data to standard format"""
        return {
            "type": "trade",
            "price": float(kraken_data["price"]),
            "volume": float(kraken_data["volume"]),
            "side": "buy" if kraken_data["side"] == "b" else "sell",
            "timestamp": float(kraken_data["timestamp"]),
        }

    @staticmethod
    def from_kraken_spread(kraken_data: dict) -> dict:
        """Convert Kraken WebSocket spread data to standard format"""
        return {
            "type": "quote",
            "bid": float(kraken_data["bid"]),
            "ask": float(kraken_data["ask"]),
            "timestamp": float(kraken_data["timestamp"]),
        }

    @staticmethod
    def from_generic_ohlc(ohlc_data: dict) -> dict:
        """Convert OHLC data to trade-like event"""
        return {
            "type": "trade",
            "price": float(ohlc_data["close"]),
            "volume": float(ohlc_data["volume"]),
            "side": "neutral",
            "timestamp": float(ohlc_data["timestamp"]),
        }


if __name__ == "__main__":
    if len(os.sys.argv) > 1 and os.sys.argv[1] == "test":
        asyncio.run(run_standalone_test())
    else:
        asyncio.run(run_production())
