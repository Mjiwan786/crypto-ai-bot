#!/usr/bin/env python3
"""
Enhanced Execution Agent with High-Frequency Scalping Support
Handles IOC, post-only, and ultra-fast order management for scalping strategies
"""

import asyncio
import time
from dataclasses import dataclass
from typing import Dict, Optional, Any
import logging

logger = logging.getLogger(__name__)

@dataclass
class OrderRequest:
    symbol: str
    side: str  # 'buy' or 'sell'
    order_type: str  # 'market', 'limit', 'post_only', 'ioc'
    quantity: float
    price: Optional[float] = None
    stop_price: Optional[float] = None
    time_in_force: str = 'GTC'  # 'GTC', 'IOC', 'FOK'
    ttl_ms: Optional[int] = None  # Time to live in milliseconds
    strategy: str = 'unknown'
    priority: str = 'normal'  # 'low', 'normal', 'high', 'scalp'

@dataclass
class OrderFill:
    order_id: str
    symbol: str
    side: str
    quantity: float
    price: float
    fee: float
    timestamp: int
    strategy: str
    execution_time_ms: float

class ScalpingExecutionEngine:
    """Ultra-fast execution engine optimized for scalping"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        
        # Scalping-specific parameters
        self.max_scalp_latency_ms = 50  # 50ms max execution time
        self.post_only_rebate_bps = -2.5  # -0.025% rebate
        self.taker_fee_bps = 15  # 0.15% taker fee
        self.slippage_tolerance_bps = 3  # 0.03% max slippage
        
        # Order management
        self.active_orders = {}
        self.scalp_positions = {}
        self.execution_stats = {
            'scalp_fills': 0,
            'scalp_cancels': 0,
            'avg_execution_time_ms': 0,
            'rebate_earned': 0.0,
            'slippage_total_bps': 0.0
        }
        
        # Fast cancel/replace tracking
        self.pending_cancels = set()
        self.replace_queue = []
        
        logger.info("⚡ Scalping Execution Engine initialized")
    
    async def execute_scalp_signal(self, signal_data: Dict[str, Any]) -> Optional[OrderFill]:
        """Execute scalping signal with ultra-low latency"""
        start_time = time.time()
        
        try:
            # Fast-path validation
            if not self._validate_scalp_signal(signal_data):
                return None
            
            # Create order request
            order_request = self._create_scalp_order(signal_data)
            
            # Route to appropriate execution method
            if order_request.order_type == 'post_only':
                fill = await self._execute_post_only(order_request)
            elif order_request.order_type == 'ioc':
                fill = await self._execute_ioc(order_request)
            else:
                fill = await self._execute_standard_limit(order_request)
            
            # Track execution performance
            execution_time_ms = (time.time() - start_time) * 1000
            self._update_execution_stats(fill, execution_time_ms)
            
            if fill:
                logger.debug(f"⚡ Scalp executed: {signal_data['symbol']} {signal_data['side']} "
                           f"in {execution_time_ms:.1f}ms")
            
            return fill
            
        except Exception as e:
            logger.error(f"Scalp execution error: {e}")
            return None
    
    def _validate_scalp_signal(self, signal_data: Dict[str, Any]) -> bool:
        """Fast validation for scalping signals"""
        
        # Required fields
        required_fields = ['symbol', 'side', 'size_quote_usd', 'order_type']
        if not all(field in signal_data for field in required_fields):
            return False
        
        # Size validation
        if signal_data['size_quote_usd'] < 10.0 or signal_data['size_quote_usd'] > 50000.0:
            return False
        
        # Strategy validation
        if signal_data.get('strategy') == 'scalp':
            # Additional scalp-specific validations
            if signal_data.get('ttl_ms', 0) > 300000:  # Max 5 minutes
                return False
            
            if signal_data.get('target_bps', 0) < 2:  # Min 2 bps target
                return False
        
        return True
    
    def _create_scalp_order(self, signal_data: Dict[str, Any]) -> OrderRequest:
        """Create optimized order request for scalping"""
        
        # Calculate quantity from USD size
        current_price = signal_data.get('current_price', signal_data.get('price', 0))
        quantity = signal_data['size_quote_usd'] / current_price
        
        # Determine optimal order type and price
        order_type = signal_data.get('order_type', 'limit')
        
        if order_type == 'post_only':
            # Price to earn rebates (inside spread)
            price = self._calculate_rebate_price(signal_data, current_price)
            time_in_force = 'GTC'
        elif order_type == 'ioc':
            # Aggressive price for immediate execution
            price = self._calculate_aggressive_price(signal_data, current_price)
            time_in_force = 'IOC'
        else:
            # Standard limit order
            price = current_price
            time_in_force = 'GTC'
        
        return OrderRequest(
            symbol=signal_data['symbol'],
            side=signal_data['side'],
            order_type=order_type,
            quantity=quantity,
            price=price,
            time_in_force=time_in_force,
            ttl_ms=signal_data.get('ttl_ms'),
            strategy=signal_data.get('strategy', 'scalp'),
            priority='scalp'
        )
    
    def _calculate_rebate_price(self, signal_data: Dict[str, Any], current_price: float) -> float:
        """Calculate price to earn maker rebates"""
        side = signal_data['side']
        spread_bps = signal_data.get('effective_spread_bps', 5)
        
        # Place order inside spread to earn rebates
        if side == 'buy':
            # Bid slightly above current best bid
            price_improvement_bps = min(spread_bps / 4, 1.0)  # 25% of spread or 1bp
            return current_price * (1 - price_improvement_bps / 10000)
        else:
            # Offer slightly below current best ask
            price_improvement_bps = min(spread_bps / 4, 1.0)
            return current_price * (1 + price_improvement_bps / 10000)
    
    def _calculate_aggressive_price(self, signal_data: Dict[str, Any], current_price: float) -> float:
        """Calculate aggressive price for immediate execution"""
        side = signal_data['side']
        
        # Cross the spread with slippage allowance
        if side == 'buy':
            # Pay above ask for immediate fill
            return current_price * (1 + self.slippage_tolerance_bps / 10000)
        else:
            # Sell below bid for immediate fill
            return current_price * (1 - self.slippage_tolerance_bps / 10000)
    
    async def _execute_post_only(self, order: OrderRequest) -> Optional[OrderFill]:
        """Execute post-only order for rebate capture"""
        
        # Simulate post-only order execution
        order_id = f"scalp_post_{int(time.time() * 1000000)}"
        
        # Post-only orders may not fill immediately
        # Simulate 70% fill rate for post-only scalp orders
        if np.random.random() < 0.7:
            fill_price = order.price
            fee = -abs(order.quantity * fill_price * self.post_only_rebate_bps / 10000)  # Negative fee = rebate
            
            self.execution_stats['rebate_earned'] += abs(fee)
            
            return OrderFill(
                order_id=order_id,
                symbol=order.symbol,
                side=order.side,
                quantity=order.quantity,
                price=fill_price,
                fee=fee,
                timestamp=int(time.time() * 1000),
                strategy=order.strategy,
                execution_time_ms=np.random.uniform(10, 30)  # Fast but not instant
            )
        
        return None  # Order didn't fill (not enough liquidity at price)
    
    async def _execute_ioc(self, order: OrderRequest) -> Optional[OrderFill]:
        """Execute IOC (Immediate or Cancel) order"""
        
        order_id = f"scalp_ioc_{int(time.time() * 1000000)}"
        
        # IOC orders have high fill rate but pay taker fees
        if np.random.random() < 0.95:  # 95% fill rate
            # Simulate market impact and slippage
            slippage_bps = np.random.uniform(0.5, 2.0)
            
            if order.side == 'buy':
                fill_price = order.price * (1 + slippage_bps / 10000)
            else:
                fill_price = order.price * (1 - slippage_bps / 10000)
            
            fee = order.quantity * fill_price * self.taker_fee_bps / 10000
            self.execution_stats['slippage_total_bps'] += slippage_bps
            
            return OrderFill(
                order_id=order_id,
                symbol=order.symbol,
                side=order.side,
                quantity=order.quantity,
                price=fill_price,
                fee=fee,
                timestamp=int(time.time() * 1000),
                strategy=order.strategy,
                execution_time_ms=np.random.uniform(5, 15)  # Very fast
            )
        
        return None
    
    async def _execute_standard_limit(self, order: OrderRequest) -> Optional[OrderFill]:
        """Execute standard limit order"""
        
        order_id = f"scalp_limit_{int(time.time() * 1000000)}"
        
        # Standard limit orders - medium fill rate
        if np.random.random() < 0.8:  # 80% fill rate
            fill_price = order.price
            fee = order.quantity * fill_price * self.taker_fee_bps / 10000
            
            return OrderFill(
                order_id=order_id,
                symbol=order.symbol,
                side=order.side,
                quantity=order.quantity,
                price=fill_price,
                fee=fee,
                timestamp=int(time.time() * 1000),
                strategy=order.strategy,
                execution_time_ms=np.random.uniform(20, 50)
            )
        
        return None
    
    async def cancel_scalp_orders(self, symbol: str, reason: str = "risk_management") -> int:
        """Cancel all scalp orders for a symbol"""
        cancelled_count = 0
        
        # Find and cancel all scalp orders for symbol
        orders_to_cancel = [
            order_id for order_id, order_data in self.active_orders.items()
            if order_data.get('symbol') == symbol and order_data.get('strategy') == 'scalp'
        ]
        
        for order_id in orders_to_cancel:
            if await self._cancel_order(order_id, reason):
                cancelled_count += 1
        
        self.execution_stats['scalp_cancels'] += cancelled_count
        
        if cancelled_count > 0:
            logger.info(f"🚫 Cancelled {cancelled_count} scalp orders for {symbol} ({reason})")
        
        return cancelled_count
    
    async def _cancel_order(self, order_id: str, reason: str) -> bool:
        """Cancel individual order"""
        if order_id in self.pending_cancels:
            return False  # Already being cancelled
        
        self.pending_cancels.add(order_id)
        
        try:
            # Simulate order cancellation
            await asyncio.sleep(0.01)  # 10ms cancellation latency
            
            if order_id in self.active_orders:
                del self.active_orders[order_id]
            
            return True
            
        except Exception as e:
            logger.error(f"Order cancellation failed: {e}")
            return False
        finally:
            self.pending_cancels.discard(order_id)
    
    async def replace_scalp_order(self, old_order_id: str, new_price: float) -> Optional[str]:
        """Fast cancel/replace for scalp orders"""
        
        if old_order_id not in self.active_orders:
            return None
        
        old_order = self.active_orders[old_order_id]
        
        # Cancel old order
        if not await self._cancel_order(old_order_id, "replace"):
            return None
        
        # Create new order with updated price
        new_order = OrderRequest(
            symbol=old_order['symbol'],
            side=old_order['side'],
            order_type=old_order['order_type'],
            quantity=old_order['quantity'],
            price=new_price,
            time_in_force=old_order['time_in_force'],
            strategy=old_order['strategy'],
            priority='scalp'
        )
        
        # Execute new order
        fill = await self.execute_scalp_signal({
            'symbol': new_order.symbol,
            'side': new_order.side,
            'size_quote_usd': new_order.quantity * new_price,
            'order_type': new_order.order_type,
            'strategy': new_order.strategy,
            'current_price': new_price
        })
        
        return fill.order_id if fill else None
    
    def _update_execution_stats(self, fill: Optional[OrderFill], execution_time_ms: float):
        """Update execution performance statistics"""
        
        if fill:
            self.execution_stats['scalp_fills'] += 1
            
            # Update average execution time
            prev_avg = self.execution_stats['avg_execution_time_ms']
            fill_count = self.execution_stats['scalp_fills']
            self.execution_stats['avg_execution_time_ms'] = (
                (prev_avg * (fill_count - 1) + execution_time_ms) / fill_count
            )
    
    def get_scalp_performance(self) -> Dict[str, Any]:
        """Get scalping execution performance metrics"""
        
        total_attempts = self.execution_stats['scalp_fills'] + self.execution_stats['scalp_cancels']
        fill_rate = (self.execution_stats['scalp_fills'] / max(total_attempts, 1)) * 100
        
        avg_slippage = (self.execution_stats['slippage_total_bps'] / 
                       max(self.execution_stats['scalp_fills'], 1))
        
        return {
            'total_scalp_fills': self.execution_stats['scalp_fills'],
            'total_scalp_cancels': self.execution_stats['scalp_cancels'],
            'fill_rate_pct': round(fill_rate, 1),
            'avg_execution_time_ms': round(self.execution_stats['avg_execution_time_ms'], 1),
            'total_rebate_earned': round(self.execution_stats['rebate_earned'], 4),
            'avg_slippage_bps': round(avg_slippage, 2),
            'active_scalp_orders': len([o for o in self.active_orders.values() 
                                      if o.get('strategy') == 'scalp']),
            'pending_cancels': len(self.pending_cancels)
        }

class EnhancedExecutionAgent:
    """Enhanced execution agent with both traditional and scalping capabilities"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        
        # Initialize specialized engines
        self.scalp_engine = ScalpingExecutionEngine(config)
        
        # Traditional execution parameters
        self.standard_fee_bps = 26  # 0.26% standard fee
        self.standard_slippage_bps = 10  # 0.1% standard slippage
        
        # Execution routing
        self.execution_stats = {
            'total_executions': 0,
            'scalp_executions': 0,
            'traditional_executions': 0
        }
        
        logger.info("⚡ Enhanced Execution Agent initialized with scalping support")
    
    async def execute_signal(self, signal_data: Dict[str, Any]) -> Optional[OrderFill]:
        """Route signal to appropriate execution engine"""
        
        self.execution_stats['total_executions'] += 1
        
        # Route scalping signals to specialized engine
        if signal_data.get('strategy') == 'scalp':
            self.execution_stats['scalp_executions'] += 1
            return await self.scalp_engine.execute_scalp_signal(signal_data)
        else:
            self.execution_stats['traditional_executions'] += 1
            return await self._execute_traditional_signal(signal_data)
    
    async def _execute_traditional_signal(self, signal_data: Dict[str, Any]) -> Optional[OrderFill]:
        """Execute traditional (non-scalping) signals"""
        
        # Standard execution logic for trend following, breakout, etc.
        current_price = signal_data.get('current_price', signal_data.get('price', 0))
        quantity = signal_data['size_quote_usd'] / current_price
        
        # Apply standard slippage and fees
        if signal_data['side'] == 'buy':
            fill_price = current_price * (1 + self.standard_slippage_bps / 10000)
        else:
            fill_price = current_price * (1 - self.standard_slippage_bps / 10000)
        
        fee = quantity * fill_price * self.standard_fee_bps / 10000
        
        return OrderFill(
            order_id=f"trad_{int(time.time() * 1000000)}",
            symbol=signal_data['symbol'],
            side=signal_data['side'],
            quantity=quantity,
            price=fill_price,
            fee=fee,
            timestamp=int(time.time() * 1000),
            strategy=signal_data.get('strategy', 'traditional'),
            execution_time_ms=np.random.uniform(100, 500)  # Slower than scalping
        )
    
    async def emergency_cancel_all_scalp(self, reason: str = "emergency_stop") -> int:
        """Emergency cancellation of all scalping orders"""
        logger.warning(f"🚨 Emergency scalp cancellation: {reason}")
        
        total_cancelled = 0
        
        # Get all unique symbols with scalp orders
        scalp_symbols = set()
        for order_data in self.scalp_engine.active_orders.values():
            if order_data.get('strategy') == 'scalp':
                scalp_symbols.add(order_data['symbol'])
        
        # Cancel all scalp orders for each symbol
        for symbol in scalp_symbols:
            cancelled = await self.scalp_engine.cancel_scalp_orders(symbol, reason)
            total_cancelled += cancelled
        
        return total_cancelled
    
    def get_comprehensive_stats(self) -> Dict[str, Any]:
        """Get comprehensive execution statistics"""
        
        scalp_performance = self.scalp_engine.get_scalp_performance()
        
        return {
            'overall': self.execution_stats,
            'scalping': scalp_performance,
            'traditional': {
                'standard_fee_bps': self.standard_fee_bps,
                'standard_slippage_bps': self.standard_slippage_bps
            }
        }

# Import numpy for the mock implementations
import numpy as np