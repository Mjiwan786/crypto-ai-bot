from __future__ import annotations
import numpy as np
from typing import List, Dict

class PerformanceMonitor:
    def __init__(self):
        self.returns: List[float] = []
        self.pred_exp: List[float] = []

    def record_trade(self, realized_ret: float, expected_ret: float | None = None):
        self.returns.append(float(realized_ret))
        if expected_ret is not None:
            self.pred_exp.append(float(expected_ret))

    def _sharpe(self):
        r = np.array(self.returns, dtype=float)
        if len(r) < 2: return 0.0
        return float(np.mean(r) / (np.std(r) + 1e-9))

    def _sortino(self):
        r = np.array(self.returns, dtype=float)
        if len(r) < 2: return 0.0
        downside = r[r<0]
        denom = np.std(downside) if len(downside) else 1e-9
        return float(np.mean(r) / denom)

    def _maxdd(self):
        r = np.array(self.returns, dtype=float)
        eq = np.cumsum(r)
        peak = np.maximum.accumulate(eq)
        dd = (eq - peak)
        return float(dd.min() if len(dd) else 0.0)

    def _ece(self):
        if not self.pred_exp or not self.returns: return 0.0
        p = np.array(self.pred_exp[:len(self.returns)])
        r = np.array(self.returns[:len(self.pred_exp)])
        return float(np.mean(np.abs(p - r)))

    def report_metrics(self) -> Dict[str, float]:
        return {
            "Sharpe": self._sharpe(),
            "Sortino": self._sortino(),
            "MaxDD": self._maxdd(),
            "ECE": self._ece(),
            "WinRate": float(np.mean(np.array(self.returns)>0) if self.returns else 0.0),
        }
