
import pytest

from crypto_ai_bot.scalper.data.ws_client import stream_ticks, Tick


@pytest.mark.asyncio
async def test_synthetic_stream_ticks_produces_ticks():
    gen = stream_ticks(symbol="BTC/USD", ws_url=None)
    ticks = []
    async for tick in gen:
        ticks.append(tick)
        if len(ticks) >= 3:
            break
    assert len(ticks) == 3
    for t in ticks:
        assert isinstance(t, Tick)
        assert t.price > 0
        assert t.volume >= 0