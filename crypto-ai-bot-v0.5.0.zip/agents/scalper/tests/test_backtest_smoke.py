from crypto_ai_bot.scalper.backtest.engine import BacktestEngine
from crypto_ai_bot.scalper.data.ws_client import Tick
from crypto_ai_bot.config.config_loader import ScalpConfig


def test_backtest_smoke_runs():
    # Create a simple upward trending price series
    ticks = []
    price = 100.0
    for i in range(50):
        price += 0.5  # trending up
        ticks.append(Tick(ts=float(i), price=price, volume=1.0, side="buy" if i % 2 == 0 else "sell"))
    config = ScalpConfig(active_strategies=["kraken_scalp"], allocations={"kraken_scalp": 1.0})
    engine = BacktestEngine(config)
    results = engine.run(ticks)
    assert "pnl" in results
    assert "win_rate" in results
    assert isinstance(results["pnl"], float)
    assert isinstance(results["win_rate"], float)