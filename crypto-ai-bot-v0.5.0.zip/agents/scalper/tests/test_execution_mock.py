from crypto_ai_bot.scalper.execution.position_manager import PositionManager


def test_position_manager_updates_net_position():
    pm = PositionManager()
    # register and fill a buy order
    pm.register_order("o1", "buy", 0.5, 100.0)
    pm.update_fill("o1", 0.5)
    assert abs(pm.net_position() - 0.5) < 1e-6
    assert pm.average_price() == 100.0
    # register and fill a sell order that reduces position
    pm.register_order("o2", "sell", 0.2, 101.0)
    pm.update_fill("o2", 0.2)
    # net position now 0.3
    assert abs(pm.net_position() - 0.3) < 1e-6
