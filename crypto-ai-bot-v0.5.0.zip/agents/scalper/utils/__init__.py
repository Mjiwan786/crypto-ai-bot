# Scalper utilities
