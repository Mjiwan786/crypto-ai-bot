"""
Scalper agent package for high-frequency trading operations.
"""

from .kraken_scalper_agent import KrakenScalperAgent

__all__ = ["KrakenScalperAgent"]
