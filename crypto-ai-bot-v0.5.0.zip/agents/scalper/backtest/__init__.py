"""
Backtesting framework for scalping strategies.
"""

# Placeholder for future backtest modules
__all__ = []
