# Package for high‑level trading agents.  Implement your agents here.
