"""
Flash Loan Executor Agent - Executes flash loan arbitrage strategies.

This module handles flash loan planning, simulation, and execution with proper
risk controls and gas optimization.
"""

import asyncio
import time
from typing import Dict, List, Optional
import logging
import json

from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, Gauge
from web3 import Web3

# Data models
class FlashloanPlan(BaseModel):
    """Flash loan execution plan."""
    asset: str = Field(..., description="Asset to borrow (e.g., USDT)")
    amount: float = Field(..., description="Amount to borrow", gt=0)
    protocol: str = Field(..., description="Lending protocol (aave, dydx)")
    route: List[str] = Field(..., description="Arbitrage route exchanges")
    max_gas_price: int = Field(50, description="Max gas price in gwei", gt=0)
    min_roi: float = Field(0.02, description="Minimum ROI threshold", gt=0)
    timeout: int = Field(300, description="Execution timeout in seconds", gt=0)
    dry_run: bool = Field(True, description="Whether to simulate only")

class ExecutionResult(BaseModel):
    """Flash loan execution result."""
    plan_id: str = Field(..., description="Plan identifier")
    success: bool = Field(..., description="Execution success status")
    tx_hash: Optional[str] = Field(None, description="Transaction hash")
    gas_used: int = Field(0, description="Gas consumed", ge=0)
    gas_price: int = Field(0, description="Gas price used in gwei", ge=0)
    profit_loss: float = Field(0, description="Realized profit/loss")
    execution_time: float = Field(0, description="Execution time in seconds", ge=0)
    error_message: Optional[str] = Field(None, description="Error details if failed")
    simulation_data: Optional[Dict] = Field(None, description="Pre-execution simulation")

class GasEstimate(BaseModel):
    """Gas estimation for flash loan execution."""
    estimated_gas: int = Field(..., description="Estimated gas units", gt=0)
    gas_price_gwei: int = Field(..., description="Recommended gas price", gt=0)
    total_cost_eth: float = Field(..., description="Total gas cost in ETH", ge=0)
    total_cost_usd: float = Field(..., description="Total gas cost in USD", ge=0)
    mev_risk_score: float = Field(..., description="MEV risk score 0-1", ge=0, le=1)

# Minimal config fallback
class LocalConfigLoader:
    def __init__(self):
        self.data = {
            'flash_loan_system': {
                'enabled': True,
                'min_roi': 0.02,
                'max_gas_price_gwei': 80,
                'gas_price_strategy': 'dynamic',
                'protocols': {
                    'aave': {
                        'max_loan_usd': 5000,
                        'health_factor': 1.3,
                        'fee_rate': 0.0009
                    },
                    'dydx': {
                        'max_loan_usd': 8000,
                        'fee_rate': 0.0
                    }
                }
            },
            'risk': {
                'circuit_breakers': [
                    {'trigger': 'consecutive_failures', 'threshold': 3}
                ]
            }
        }

# Minimal MCP fallback
class LocalMCP:
    def __init__(self):
        self.kv = {}
    
    async def publish(self, topic: str, payload: dict):
        print(f"[MCP] Published to {topic}: {payload}")
        
    def get(self, key: str, default=None):
        return self.kv.get(key, default)
    
    def set(self, key: str, value):
        self.kv[key] = value

class Web3Adapter:
    """Abstracted Web3 interface for testing and mocking."""
    
    def __init__(self, rpc_url: str = "https://mainnet.infura.io/v3/demo"):
        try:
            self.w3 = Web3(Web3.HTTPProvider(rpc_url))
            self.connected = self.w3.is_connected()
        except Exception:
            self.w3 = None
            self.connected = False
    
    async def estimate_gas(self, transaction: dict) -> int:
        """Estimate gas for a transaction."""
        if not self.connected:
            # Mock gas estimation
            return 150000 + len(str(transaction)) * 100
        
        try:
            return self.w3.eth.estimate_gas(transaction)
        except Exception:
            return 200000  # Fallback estimate
    
    async def get_gas_price(self) -> int:
        """Get current gas price in wei."""
        if not self.connected:
            return 20 * 10**9  # 20 gwei mock
        
        try:
            return self.w3.eth.gas_price
        except Exception:
            return 25 * 10**9  # Fallback
    
    async def send_transaction(self, transaction: dict) -> str:
        """Send a transaction (mock implementation)."""
        if not self.connected:
            # Generate mock transaction hash
            import hashlib
            tx_data = json.dumps(transaction, sort_keys=True)
            return f"0x{hashlib.sha256(tx_data.encode()).hexdigest()}"
        
        # In production, this would sign and send the real transaction
        raise NotImplementedError("Real transaction sending not implemented in demo")

class FlashloanExecutor:
    """
    Executes flash loan arbitrage strategies.
    
    This agent handles flash loan planning, simulation, and execution with
    comprehensive risk controls and gas optimization.
    """
    
    def __init__(self, mcp=None, redis=None, logger=None, **kwargs):
        """
        Initialize the Flash Loan Executor.
        
        Args:
            mcp: Model Context Protocol instance
            redis: Redis instance for state management
            logger: Logger instance
            **kwargs: Additional configuration
        """
        self.mcp = mcp or LocalMCP()
        self.redis = redis
        self.logger = logger or logging.getLogger(__name__)
        
        # Load configuration
        try:
            from config.config_loader import ConfigLoader
            config = ConfigLoader()
            self.config = config.data
        except ImportError:
            self.config = LocalConfigLoader().data
            self.logger.warning("Using fallback config - config_loader not available")
        
        self.fl_config = self.config.get('flash_loan_system', {})
        self.enabled = self.fl_config.get('enabled', True)
        self.min_roi = self.fl_config.get('min_roi', 0.02)
        self.max_gas_price = self.fl_config.get('max_gas_price_gwei', 80)
        
        # Initialize Web3 adapter
        self.web3_adapter = Web3Adapter()
        
        # Circuit breaker state
        self.consecutive_failures = 0
        self.circuit_breaker_active = False
        self.last_failure_time = 0
        
        # Metrics
        self.metrics = self._init_metrics()
        
        # Protocol configurations
        self.protocols = self.fl_config.get('protocols', {})
        
        self.logger.info("FlashloanExecutor initialized")
        if not self.enabled:
            self.logger.warning("Flash loan system is DISABLED in config")
    
    def _init_metrics(self) -> Dict:
        """Initialize Prometheus metrics."""
        return {
            'executions_total': Counter(
                'flashloan_executions_total',
                'Total flash loan executions',
                ['protocol', 'status']
            ),
            'execution_duration': Histogram(
                'flashloan_execution_duration_seconds',
                'Flash loan execution time'
            ),
            'gas_used': Histogram(
                'flashloan_gas_used_total',
                'Gas consumed by flash loans'
            ),
            'profit_loss': Histogram(
                'flashloan_profit_loss_usd',
                'Profit/loss from flash loans',
                buckets=(-100, -50, -25, -10, 0, 10, 25, 50, 100, 250, 500, float('inf'))
            ),
            'active_loans': Gauge(
                'flashloan_active_count',
                'Currently active flash loans'
            )
        }
    
    def _check_circuit_breaker(self) -> bool:
        """Check if circuit breaker should be triggered."""
        if self.consecutive_failures >= 3:
            if not self.circuit_breaker_active:
                self.circuit_breaker_active = True
                self.logger.warning("Circuit breaker ACTIVATED due to consecutive failures")
            return True
        
        # Auto-reset after 1 hour
        if self.circuit_breaker_active and time.time() - self.last_failure_time > 3600:
            self.circuit_breaker_active = False
            self.consecutive_failures = 0
            self.logger.info("Circuit breaker RESET after cooldown period")
        
        return self.circuit_breaker_active
    
    async def _estimate_mev_risk(self, plan: FlashloanPlan) -> float:
        """
        Estimate MEV (Maximum Extractable Value) risk score.
        
        Args:
            plan: Flash loan plan to analyze
            
        Returns:
            Risk score between 0 (low) and 1 (high)
        """
        # Simple MEV risk heuristics
        risk_factors = []
        
        # Large amounts attract more MEV bots
        if plan.amount > 10000:
            risk_factors.append(0.3)
        elif plan.amount > 50000:
            risk_factors.append(0.5)
        
        # Popular routes have higher MEV competition
        popular_exchanges = {'uniswap', 'sushiswap', 'balancer'}
        route_popularity = len([ex for ex in plan.route if ex.lower() in popular_exchanges])
        if route_popularity > 0:
            risk_factors.append(route_popularity * 0.2)
        
        # Base MEV risk
        risk_factors.append(0.1)
        
        return min(1.0, sum(risk_factors))
    
    async def _simulate_gas_cost(self, plan: FlashloanPlan) -> GasEstimate:
        """
        Simulate gas costs for flash loan execution.
        
        Args:
            plan: Flash loan plan
            
        Returns:
            GasEstimate with cost breakdown
        """
        # Mock transaction for gas estimation
        mock_transaction = {
            'to': '0x7d2768dE32b0b80b7a3452a7dFfE036Ac10ff4EE',  # Aave pool
            'value': 0,
            'data': '0x' + '00' * 200,  # Mock flash loan call data
            'gas': 500000
        }
        
        # Estimate gas and get current gas price
        estimated_gas = await self.web3_adapter.estimate_gas(mock_transaction)
        current_gas_price_wei = await self.web3_adapter.get_gas_price()
        current_gas_price_gwei = current_gas_price_wei // 10**9
        
        # Apply gas price strategy
        if self.fl_config.get('gas_price_strategy') == 'dynamic':
            recommended_gas_price = min(current_gas_price_gwei + 5, self.max_gas_price)
        else:
            recommended_gas_price = min(current_gas_price_gwei, self.max_gas_price)
        
        # Calculate costs
        total_gas_cost_wei = estimated_gas * recommended_gas_price * 10**9
        total_cost_eth = total_gas_cost_wei / 10**18
        
        # Mock ETH price for USD calculation
        eth_price_usd = 2000.0  # Fallback price
        total_cost_usd = total_cost_eth * eth_price_usd
        
        # Get MEV risk
        mev_risk = await self._estimate_mev_risk(plan)
        
        return GasEstimate(
            estimated_gas=estimated_gas,
            gas_price_gwei=recommended_gas_price,
            total_cost_eth=total_cost_eth,
            total_cost_usd=total_cost_usd,
            mev_risk_score=mev_risk
        )
    
    async def _validate_plan(self, plan: FlashloanPlan) -> tuple[bool, str]:
        """
        Validate flash loan plan for safety and feasibility.
        
        Args:
            plan: Flash loan plan to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not self.enabled:
            return False, "Flash loan system is disabled"
        
        if self._check_circuit_breaker():
            return False, "Circuit breaker active - system in cooldown"
        
        # Check protocol support
        if plan.protocol not in self.protocols:
            return False, f"Unsupported protocol: {plan.protocol}"
        
        # Check loan limits
        protocol_config = self.protocols[plan.protocol]
        max_loan = protocol_config.get('max_loan_usd', 10000)
        if plan.amount > max_loan:
            return False, f"Loan amount ${plan.amount} exceeds limit ${max_loan}"
        
        # Check minimum ROI
        if plan.min_roi < self.min_roi:
            return False, f"ROI {plan.min_roi:.2%} below minimum {self.min_roi:.2%}"
        
        # Validate route
        if not plan.route or len(plan.route) < 2:
            return False, "Invalid arbitrage route - need at least 2 exchanges"
        
        return True, ""
    
    async def simulate_once(self, plan: FlashloanPlan) -> ExecutionResult:
        """
        Simulate flash loan execution without actual execution.
        
        Args:
            plan: Flash loan plan to simulate
            
        Returns:
            ExecutionResult with simulation data
            
        Raises:
            ValueError: If plan is invalid
        """
        start_time = time.time()
        plan_id = f"sim_{int(time.time())}_{hash(str(plan))}"
        
        try:
            # Validate plan
            is_valid, error_msg = await self._validate_plan(plan)
            if not is_valid:
                return ExecutionResult(
                    plan_id=plan_id,
                    success=False,
                    error_message=error_msg,
                    execution_time=time.time() - start_time
                )
            
            # Estimate gas costs
            gas_estimate = await self._simulate_gas_cost(plan)
            
            # Calculate expected profit
            protocol_fee_rate = self.protocols[plan.protocol].get('fee_rate', 0.0009)
            loan_fee = plan.amount * protocol_fee_rate
            gas_cost_usd = gas_estimate.total_cost_usd
            
            # Mock arbitrage profit calculation
            mock_spread = plan.min_roi + 0.005  # Assume slightly higher than minimum
            gross_profit = plan.amount * mock_spread
            net_profit = gross_profit - loan_fee - gas_cost_usd
            
            # Factor in MEV risk
            mev_penalty = net_profit * gas_estimate.mev_risk_score * 0.5
            final_profit = net_profit - mev_penalty
            
            simulation_data = {
                'gross_profit': gross_profit,
                'loan_fee': loan_fee,
                'gas_cost': gas_cost_usd,
                'mev_penalty': mev_penalty,
                'net_profit': final_profit,
                'gas_estimate': gas_estimate.dict(),
                'expected_roi': final_profit / plan.amount if plan.amount > 0 else 0
            }
            
            success = final_profit > 0 and simulation_data['expected_roi'] >= plan.min_roi
            
            result = ExecutionResult(
                plan_id=plan_id,
                success=success,
                gas_used=gas_estimate.estimated_gas,
                gas_price=gas_estimate.gas_price_gwei,
                profit_loss=final_profit,
                execution_time=time.time() - start_time,
                simulation_data=simulation_data,
                error_message=None if success else "Simulation shows unprofitable execution"
            )
            
            self.logger.info(f"Simulation {plan_id}: {'PROFITABLE' if success else 'UNPROFITABLE'} "
                           f"(${final_profit:.2f}, {simulation_data['expected_roi']:.2%} ROI)")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Simulation failed for {plan_id}: {e}")
            return ExecutionResult(
                plan_id=plan_id,
                success=False,
                error_message=str(e),
                execution_time=time.time() - start_time
            )
    
    async def execute(self, plan: FlashloanPlan) -> ExecutionResult:
        """
        Execute flash loan arbitrage plan.
        
        Args:
            plan: Flash loan plan to execute
            
        Returns:
            ExecutionResult with execution details
            
        Raises:
            Exception: If execution fails critically
        """
        start_time = time.time()
        plan_id = f"exec_{int(time.time())}_{hash(str(plan))}"
        
        try:
            # Always simulate first
            simulation = await self.simulate_once(plan)
            if not simulation.success:
                self.logger.warning(f"Pre-execution simulation failed for {plan_id}")
                return simulation
            
            # Check if dry run
            if plan.dry_run:
                self.logger.info(f"DRY RUN: Would execute {plan_id} with ${simulation.profit_loss:.2f} profit")
                return ExecutionResult(
                    plan_id=plan_id,
                    success=True,
                    gas_used=simulation.gas_used,
                    gas_price=simulation.gas_price,
                    profit_loss=simulation.profit_loss,
                    execution_time=time.time() - start_time,
                    simulation_data=simulation.simulation_data,
                    error_message="DRY RUN - no actual execution"
                )
            
            # Real execution (mock for demo safety)
            self.logger.warning("REAL EXECUTION DISABLED FOR DEMO SAFETY")
            mock_tx_hash = f"0x{'0' * 64}"  # Mock transaction hash
            
            # In production, this would:
            # 1. Prepare flash loan transaction
            # 2. Execute arbitrage route
            # 3. Repay flash loan + fees
            # 4. Return profits
            
            # Update metrics
            self.metrics['executions_total'].labels(
                protocol=plan.protocol, 
                status='success'
            ).inc()
            self.metrics['execution_duration'].observe(time.time() - start_time)
            self.metrics['gas_used'].observe(simulation.gas_used)
            self.metrics['profit_loss'].observe(simulation.profit_loss)
            
            # Reset failure counter on success
            self.consecutive_failures = 0
            
            result = ExecutionResult(
                plan_id=plan_id,
                success=True,
                tx_hash=mock_tx_hash,
                gas_used=simulation.gas_used,
                gas_price=simulation.gas_price,
                profit_loss=simulation.profit_loss,
                execution_time=time.time() - start_time,
                simulation_data=simulation.simulation_data
            )
            
            # Publish execution result
            await self.mcp.publish('exec.trades', {
                'type': 'flashloan_execution',
                'result': result.dict(),
                'timestamp': time.time()
            })
            
            return result
            
        except Exception as e:
            # Handle execution failure
            self.consecutive_failures += 1
            self.last_failure_time = time.time()
            
            self.metrics['executions_total'].labels(
                protocol=plan.protocol, 
                status='failure'
            ).inc()
            
            self.logger.error(f"Execution failed for {plan_id}: {e}")
            
            return ExecutionResult(
                plan_id=plan_id,
                success=False,
                error_message=str(e),
                execution_time=time.time() - start_time
            )
    
    async def start(self):
        """Start the flash loan executor service."""
        self.logger.info("FlashloanExecutor service started")
        # This agent is primarily reactive, no continuous loop needed
        
    async def stop(self):
        """Stop the flash loan executor service gracefully."""
        self.logger.info("Stopping FlashloanExecutor service")
        # Clean up any pending transactions or connections

# Demo/test runner
if __name__ == "__main__":
    async def demo():
        """Demo the FlashloanExecutor with safe simulation."""
        logging.basicConfig(level=logging.INFO)
        
        executor = FlashloanExecutor()
        
        print("⚡ Running FlashloanExecutor demo...")
        print("This is a SAFE DEMO - no real flash loans will be executed")
        print("-" * 60)
        
        # Create test flash loan plan
        test_plan = FlashloanPlan(
            asset="USDT",
            amount=5000.0,
            protocol="aave",
            route=["uniswap_v3", "sushiswap"],
            max_gas_price=50,
            min_roi=0.015,  # 1.5% minimum ROI
            dry_run=True
        )
        
        print("📋 Test Plan:")
        print(f"   Asset: {test_plan.asset}")
        print(f"   Amount: ${test_plan.amount:,.0f}")
        print(f"   Protocol: {test_plan.protocol}")
        print(f"   Route: {' → '.join(test_plan.route)}")
        print(f"   Min ROI: {test_plan.min_roi:.1%}")
        print(f"   Dry Run: {test_plan.dry_run}")
        
        try:
            # Run simulation
            print("\n🔬 Running simulation...")
            simulation = await executor.simulate_once(test_plan)
            
            if simulation.success:
                sim_data = simulation.simulation_data
                print("✅ Simulation SUCCESSFUL:")
                print(f"   Gross Profit: ${sim_data['gross_profit']:.2f}")
                print(f"   Loan Fee: ${sim_data['loan_fee']:.2f}")
                print(f"   Gas Cost: ${sim_data['gas_cost']:.2f}")
                print(f"   MEV Penalty: ${sim_data['mev_penalty']:.2f}")
                print(f"   Net Profit: ${sim_data['net_profit']:.2f}")
                print(f"   Expected ROI: {sim_data['expected_roi']:.2%}")
                print(f"   Gas Estimate: {sim_data['gas_estimate']['estimated_gas']:,} units")
                print(f"   MEV Risk: {sim_data['gas_estimate']['mev_risk_score']:.1%}")
                
                # Test execution (dry run)
                print("\n⚡ Running execution (DRY RUN)...")
                execution = await executor.execute(test_plan)
                
                if execution.success:
                    print("✅ Execution SUCCESSFUL (simulated):")
                    print(f"   Plan ID: {execution.plan_id}")
                    print(f"   Profit: ${execution.profit_loss:.2f}")
                    print(f"   Gas Used: {execution.gas_used:,} units")
                    print(f"   Execution Time: {execution.execution_time:.2f}s")
                else:
                    print(f"❌ Execution FAILED: {execution.error_message}")
            else:
                print(f"❌ Simulation FAILED: {simulation.error_message}")
            
        except Exception as e:
            print(f"❌ Demo failed: {e}")
        finally:
            await executor.stop()
        
        print("\n" + "=" * 60)
        print("💡 FlashloanExecutor demo completed!")
        print("💡 Real execution requires proper Web3 setup and is DISABLED for safety")
        print("💡 Always test thoroughly before using with real funds")
    
    asyncio.run(demo())