"""
Simple config loader for agents - simplified version
"""
import os
from typing import Any, Optional

class SimpleConfig:
    """Simple configuration class for agents"""
    
    def __init__(self):
        # Load from environment variables with defaults
        self.data = {
            # Toxic flow settings
            'TOXIC_IMBALANCE_THRESHOLD': float(os.getenv('TOXIC_IMBALANCE_THRESHOLD', '0.8')),
            'TOXIC_VOLATILITY_THRESHOLD': float(os.getenv('TOXIC_VOLATILITY_THRESHOLD', '50.0')),
            'TOXIC_MOMENTUM_THRESHOLD': float(os.getenv('TOXIC_MOMENTUM_THRESHOLD', '0.7')),
            'TOXIC_CASCADE_VOLUME_MULT': float(os.getenv('TOXIC_CASCADE_VOLUME_MULT', '3.0')),
            
            # Scalping settings
            'SCALP_MAX_TOXICITY_SCORE': float(os.getenv('SCALP_MAX_TOXICITY_SCORE', '0.6')),
            'SCALP_MAX_ADVERSE_SELECTION_RISK': float(os.getenv('SCALP_MAX_ADVERSE_SELECTION_RISK', '0.7')),
            'SCALP_MAX_MARKET_IMPACT_RISK': float(os.getenv('SCALP_MAX_MARKET_IMPACT_RISK', '0.8')),
            'SCALP_COOLDOWN_AFTER_LOSS_SECONDS': int(os.getenv('SCALP_COOLDOWN_AFTER_LOSS_SECONDS', '90')),
            
            # General settings
            'ENVIRONMENT': os.getenv('ENVIRONMENT', 'prod'),
            'LOG_LEVEL': os.getenv('LOG_LEVEL', 'INFO'),
        }
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        return self.data.get(key, default)
    
    def __getitem__(self, key: str) -> Any:
        """Allow dict-like access"""
        return self.data[key]
    
    def __contains__(self, key: str) -> bool:
        """Allow 'in' operator"""
        return key in self.data

# Global config instance
_config_instance: Optional[SimpleConfig] = None

def get_config() -> SimpleConfig:
    """Get the global configuration instance"""
    global _config_instance
    if _config_instance is None:
        _config_instance = SimpleConfig()
    return _config_instance

def reload_config() -> SimpleConfig:
    """Force reload the configuration"""
    global _config_instance
    _config_instance = SimpleConfig()
    return _config_instance

class ConfigLoader:
    """Config loader class for compatibility"""
    
    def load_config(self) -> SimpleConfig:
        return get_config()