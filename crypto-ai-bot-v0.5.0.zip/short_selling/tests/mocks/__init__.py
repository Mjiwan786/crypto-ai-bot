# Short selling test mocks
